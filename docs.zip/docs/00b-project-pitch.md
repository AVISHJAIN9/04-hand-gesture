# Project Pitch: Touchless Chef

## 1. 30-Second Elevator Pitch

> "I built Touchless Chef, a client-side computer vision web application that allows culinary chefs, medical trainees, and workshop instructors to control recipe video playback completely hands-free using natural hand gestures. By integrating Google MediaPipe's pre-trained Vision Tasks running on WebAssembly and WebGL inside the browser, gestures like an Open Palm to play and pause, Pointing Up to skip forward, or Thumbs Up to zoom into a cooking technique execute with zero latency. Because the neural network runs entirely on the user's device, no video feed ever leaves the browser, guaranteeing complete privacy and zero backend cloud hosting costs. It solves the real-world frustration of smudging screens or contaminating clean food prep stations with messy, wet, or gloved hands."

---

## 2. 2-Minute Comprehensive Interview Pitch

> "In professional kitchens, cooking schools, and laboratory workshops, people frequently rely on instructional video streams while performing messy, tactile tasks. Whether a chef has hands covered in raw chicken, flour, or oil, or a medical technician is wearing sterile surgical gloves, touching a laptop screen, mouse, or phone creates serious contamination risks and damages expensive hardware.
>
> To solve this, I designed and developed **Touchless Chef**, an edge AI computer vision application built on React 18, Vite, Tailwind CSS, and Google MediaPipe Vision Tasks.
>
> When the application loads, it initializes Google's float16 quantized gesture recognition model through WebAssembly and attaches to the local webcam stream via the HTML5 `getUserMedia` API. The video frames are processed at 60 frames per second using client-side GPU acceleration, classifying hand landmarks into five distinct control gestures: an **Open Palm** toggles play and pause; **Pointing Up** skips forward 10 seconds; the **Victory peace sign** rewinds 10 seconds; **Thumbs Up** zooms the video into 125% for close inspection of fine knife skills; and **Thumbs Down** resets the zoom back to 100%.
>
> From an engineering standpoint, the biggest challenges were false positive triggers, rapid jitter, and browser performance. I solved these by introducing a strict dual-filter architecture: first, predictions are discarded unless the model's confidence exceeds 75%; second, I engineered a 1500-millisecond timestamp cooldown using React's `useRef`, preventing continuous hand presence from firing duplicate commands across consecutive animation frames.
>
> I deliberately chose an on-device WebAssembly execution model instead of streaming frames to a Python or cloud-hosted computer vision backend. This decision reduced our API latency from 250 milliseconds down to under 15 milliseconds, eliminated cloud inference server bills entirely, and ensured absolute user privacy because camera frames never leave the client's local memory.
>
> Overall, the project demonstrates how modern browser capabilities and quantized machine learning models can deliver intuitive, hardware-accelerated user experiences without costly backend infrastructure."

---

## 3. High-Level Pitch Flow

```mermaid
flowchart LR
    A["Real-World Problem<br/>Messy/gloved hands contaminate screens"] --> B["Technical Solution<br/>Edge AI Gesture Recognition via MediaPipe WASM/GPU"]
    B --> C["Core Gestures<br/>Play/Pause, +/-10s Skip, 125% Zoom"]
    C --> D["Key Engineering Feats<br/>75% Confidence Filter, 1500ms Cooldown, 0-Latency Privacy"]
    D --> E["Business Value<br/>$0 Server Inference Costs, 100% Privacy, Universal Web Delivery"]
```
