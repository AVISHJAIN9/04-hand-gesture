# Step 2.5: Say It Out Loud (Spoken Interview Rehearsal Guide)

This master rehearsal document compiles the first-person, spoken-English scripts for every single feature in Touchless Chef. 

> [!TIP]
> **How to Rehearse**: Read these scripts out loud. Do not memorize them word for word—internalize the five-step spoken flow:
> 1. What the feature does and why the user needs it.
> 2. How it works step by step from user action to the browser and back, naming real components and services.
> 3. Why this approach was chosen and the main alternative rejected.
> 4. What happens when it fails and how it is handled.
> 5. One honest limitation and what you would improve next.

---

## 30-Second Project Elevator Pitch

"I built Touchless Chef, a client-side computer vision web application that allows culinary chefs, medical trainees, and workshop instructors to control recipe video playback completely hands-free using natural hand gestures. By integrating Google MediaPipe's pre-trained Vision Tasks running on WebAssembly and WebGL inside the browser, gestures like an Open Palm to play and pause, Pointing Up to skip forward, or Thumbs Up to zoom into a cooking technique execute with zero latency. Because the neural network runs entirely on the user's device, no video feed ever leaves the browser, guaranteeing complete privacy and zero backend cloud hosting costs. It solves the real-world frustration of smudging screens or contaminating clean food prep stations with messy, wet, or gloved hands."

---

## 2-Minute Comprehensive Project Pitch

"In professional kitchens, cooking schools, and laboratory workshops, people frequently rely on instructional video streams while performing messy, tactile tasks. Whether a chef has hands covered in raw chicken, flour, or oil, or a medical technician is wearing sterile surgical gloves, touching a laptop screen, mouse, or phone creates serious contamination risks and damages expensive hardware.

To solve this, I designed and developed Touchless Chef, an edge AI computer vision application built on React 18, Vite, Tailwind CSS, and Google MediaPipe Vision Tasks.

When the application loads, it initializes Google's float16 quantized gesture recognition model through WebAssembly and attaches to the local webcam stream via the HTML5 `getUserMedia` API. The video frames are processed at 60 frames per second using client-side GPU acceleration, classifying hand landmarks into five distinct control gestures: an Open Palm toggles play and pause; Pointing Up skips forward 10 seconds; the Victory peace sign rewinds 10 seconds; Thumbs Up zooms the video into 125% for close inspection of fine knife skills; and Thumbs Down resets the zoom back to 100%.

From an engineering standpoint, the biggest challenges were false positive triggers, rapid jitter, and browser performance. I solved these by introducing a strict dual-filter architecture: first, predictions are discarded unless the model's confidence exceeds 75%; second, I engineered a 1500-millisecond timestamp cooldown using React's `useRef`, preventing continuous hand presence from firing duplicate commands across consecutive animation frames.

I deliberately chose an on-device WebAssembly execution model instead of streaming frames to a Python or cloud-hosted computer vision backend. This decision reduced our API latency from 250 milliseconds down to under 15 milliseconds, eliminated cloud inference server bills entirely, and ensured absolute user privacy because camera frames never leave the client's local memory.

Overall, the project demonstrates how modern browser capabilities and quantized machine learning models can deliver intuitive, hardware-accelerated user experiences without costly backend infrastructure."

---

## F1: Real-Time Edge AI Hand Gesture Recognition Engine
*Spoken Depth: Core Feature (20 lines)*

"In this project, I built the core AI vision engine using Google MediaPipe's Vision Tasks, which runs a pre-trained gesture recognition neural network directly in the user's browser.

When the video player component mounts, my `GestureManager` service fetches the WebAssembly runtime and the float16 quantized model bundle from Google's CDN, compiling the model onto the user's local GPU using WebGL. Once camera access is granted, I start a continuous `requestAnimationFrame` loop that feeds live 640-by-480 webcam frames into `recognizeVideo` along with high-resolution timestamps.

For every frame, MediaPipe extracts 21 three-dimensional hand landmarks and classifies the pose. To prevent accidental triggers caused by kitchen utensils or background movements, I enforce a strict confidence threshold of 0.75 before accepting any gesture.

I chose this client-side edge AI approach over a traditional Python FastAPI backend because streaming video over WebSockets or HTTP would introduce 200 to 400 milliseconds of latency, consume massive server bandwidth, and raise severe privacy concerns for home users.

If the network drops or the CDN fails to serve the model bundle, the initialization promise rejects, gets caught in my error boundary, and the UI gracefully informs the chef while keeping standard manual controls intact.

One current limitation is that it only tracks one hand at a time and requires reasonable kitchen lighting. If I were to improve it, I would add automatic exposure compensation and support multi-hand interactions."

---

## F2: Touchless Video Play / Pause Control
*Spoken Depth: Medium Feature (9 lines)*

"I implemented the touchless play and pause feature to give chefs immediate control over their recipe video without ever reaching for a greasy keyboard or smudging a tablet screen.

When the user displays an open palm facing the webcam, MediaPipe detects the `Open_Palm` category with a confidence over 75 percent. My `executeCommand` function inspects the native `paused` property of the HTML5 video element using a React `useRef`. If the video is paused, it calls `.play()` and updates the UI feedback to 'Playing'; if it is already playing, it calls `.pause()` and updates the state to 'Paused'.

I chose native HTML5 video methods directly on the DOM node instead of wrapping the player in external heavy libraries like Video.js to keep bundle size small and execution instant.

If the browser blocks video playback due to autoplay restrictions, the promise rejection is handled safely without throwing an unhandled exception.

One limitation is that an open hand briefly waved while reaching for a spice jar can trigger it if held too long, so I bound it to our 1.5-second cooldown engine to prevent rapid cycling."

---

## F3: Precision Video Seeking (+/- 10 Seconds)
*Spoken Depth: Medium Feature (9 lines)*

"I designed the precision video seeking feature so cooks can instantly replay a missed culinary instruction or skip over repetitive cooking steps without touching their device.

When the user points an index finger upward, MediaPipe registers `Pointing_Up` and I advance the video's `currentTime` property by 10 seconds. When they make a peace sign, the model registers `Victory` and I subtract 10 seconds.

In the code, I explicitly protect against boundary errors by wrapping the calculations in `Math.min` with `video.duration` and `Math.max` with zero. This guarantees that scrubbing near the beginning or end of the video never results in negative timestamps or out-of-bounds playback errors.

I chose a fixed 10-second interval because user testing in cooking environments revealed that culinary instructions are typically delivered in 5 to 15-second bite-sized steps, making 10 seconds the sweet spot.

If the video is still buffering and hasn't loaded its metadata duration yet, the clamping gracefully handles the state.

An improvement I would make is dynamic variable scrubbing: holding the gesture longer could accelerate the jump from 10 seconds to 30 or 60 seconds."

---

## F4: Interactive Frame Zoom & Inspection (125% / 100%)
*Spoken Depth: Medium Feature (9 lines)*

"I added the interactive frame zoom feature to solve a specific culinary problem: when watching cooking tutorials, delicate knife cuts, dough kneading consistency, or sauce thickness are often hard to see clearly from across the kitchen counter.

When the chef presents a Thumbs Up gesture, MediaPipe classifies `Thumb_Up` and I apply a hardware-accelerated CSS transform of `scale(1.25)` with a 300-millisecond ease transition directly to the video element. When they show a Thumbs Down, it smoothly resets back to scale 1.0.

I chose CSS transforms applied directly through DOM refs over canvas cropping or re-rendering because CSS transforms run on the browser's GPU compositor layer. This guarantees a silky smooth 60 frames per second animation without causing layout reflows or dropping video frames.

To ensure the enlarged video doesn't break the surrounding dashboard layout, I contained the player inside an `overflow-hidden` wrapper.

One limitation is that the zoom currently centers on the middle of the frame. In a future iteration, I plan to use hand landmark positions to pan the zoomed area directly to the point where the chef is gesturing."

---

## F5: 1500ms Action Debounce & Cooldown Engine
*Spoken Depth: Core Feature (16 lines)*

"A critical engineering problem in real-time computer vision is the 'jitter and rapid trigger' dilemma: our camera and MediaPipe model process video at 60 frames every second. If a cook raises an open palm for just half a second, the model classifies that gesture 30 times consecutively. Without throttling, the player would violently toggle between play and pause 30 times in the blink of an eye.

To solve this, I engineered an action cooldown engine using React's `useRef` to store the exact timestamp of the last executed command.

In every animation frame of my `predictLoop`, once a gesture clears the 75 percent confidence hurdle, I calculate `Date.now() - lastActionTime.current`. If less than 1500 milliseconds have elapsed since the last command, the event is suppressed, while the visual HUD still updates to show the live detected gesture. Only when the 1.5-second cooldown window has passed does `executeCommand` fire and the timer resets to the current timestamp.

I deliberately chose `useRef` instead of React `useState` because `useRef` allows me to mutate the timestamp synchronously across 60 FPS animation frames without triggering unnecessary React re-renders, which would otherwise drop video frames and degrade performance.

If a user intentionally wants to skip forward multiple times quickly, they have to wait 1.5 seconds between skips.

As a next step, I would implement adaptive cooldowns: a 1.5-second cooldown for play and pause toggles, but a shorter 500-millisecond cooldown for seeking, with support for gesture holds."

---

## F6: Real-Time HUD Overlay & Live Gesture Indicators
*Spoken Depth: Small Feature (6 lines)*

"In any touchless or voice-controlled system, visual feedback is crucial so users never have to guess whether the computer saw them.

I implemented a floating Heads-Up Display directly over the video player. In the top-right corner, an emerald pulsing pill shows the raw gesture MediaPipe is currently detecting in real time, like 'Open Palm' or 'Pointing Up'. In the top-left, a blurred glassmorphic badge displays the action taken, such as 'Playing', 'Paused', or 'Jumped Forward (+10s)'.

I styled these with Tailwind CSS using `pointer-events-none` so the overlays don't block manual mouse clicks on the underlying video controls, and added background blur for high legibility across dark and bright recipe scenes.

If no gesture is present, the detection badge unmounts cleanly to keep the viewing canvas uncluttered.

Currently, the feedback text stays visible until the next action. A small improvement would be to fade it out automatically after two seconds."

---

## F7: Mirrored Vision Stream Inset Monitor & Toggle
*Spoken Depth: Medium Feature (8 lines)*

"When using computer vision, users often don't know why a gesture isn't working—whether their hand is out of the camera's frame or if backlighting is washing out their silhouette.

To solve this, I built an optional Picture-in-Picture webcam inset in the bottom-right corner of the player. Users can toggle it on or off with a single click on the control bar.

In the code, I feed the same live `MediaStream` used by MediaPipe into this preview element, applying Tailwind's `-scale-x-100` utility to horizontally mirror the feed. This ensures when a chef moves their right hand, the preview behaves just like a natural mirror instead of an inverted webcam.

By default, the inset is hidden using CSS opacity and `pointer-events-none`, keeping the video distraction-free once the chef is positioned comfortably.

If the camera isn't active yet, the inset remains empty with a subtle emerald border.

One improvement I'd like to add is rendering MediaPipe's skeletal hand landmarks directly on the inset canvas so users can see the neural network tracking their joints."

---

## F8: Preset Recipe Stream Switcher
*Spoken Depth: Small Feature (6 lines)*

"To make the application instantly usable without requiring users to find and upload their own video files, I built an interactive preset recipe switcher.

In `App.jsx`, I maintain a curated array of high-definition video streams hosted on Google Cloud Storage, including culinary recipe clips and nature demos. When the user clicks any of the preset buttons, React updates the `videoUrl` state, which flows down as a prop into `ChefVideoPlayer`.

Crucially, because my computer vision tracking loop is decoupled from the video source URL, switching recipes updates the video stream immediately without re-initializing the MediaPipe model or dropping the webcam connection.

The active video button is highlighted with an emerald border and subtle glow so the user always knows which stream is loaded.

If a video fails to stream due to CORS or network issues, the HTML5 video element surfaces its native error state.

In the future, I would like to connect this switcher to a YouTube or Vimeo API to let users search real culinary channels directly."

---

## F9: Custom Direct Video Stream / URL Ingestion
*Spoken Depth: Small Feature (7 lines)*

"To make Touchless Chef truly practical for real-world cooking workshops, I built a custom video stream loader.

Users can paste any direct MP4 or WebM video link into an input field below the player and click 'Load Video'. My `handleCustomSubmit` function intercepts the form submission, prevents the default browser reload, sanitizes the URL by trimming whitespace, and updates the application's root `videoUrl` state.

This gives instructors the flexibility to load their own recipe tutorials or workshop recordings directly from cloud storage buckets or content delivery networks.

Because the form is built with controlled React inputs, the text field clears automatically upon submission for a clean user experience.

If a user enters an invalid or unreachable video link, the browser's video element displays standard error indicators without crashing the JavaScript runtime.

In the next release, I'd like to add local drag-and-drop file support using the HTML5 File API so users can play offline video files without needing to host them online."

---

## F10: Hardware Camera Acquisition & Lifecycle Teardown
*Spoken Depth: Core Feature (15 lines)*

"Managing hardware lifecycles properly in browser applications is something junior developers often overlook. In Touchless Chef, I encapsulated webcam acquisition and resource cleanup inside my `GestureManager` singleton.

When the player mounts, `startCamera` requests user permission via `navigator.mediaDevices.getUserMedia`, constraining the stream to 640-by-480 resolution with a front-facing camera preference. This resolution provides the optimal balance between high landmark tracking accuracy and low GPU memory bandwidth.

Once permission is granted, I attach the stream directly to the video element's `srcObject` property and return true, which activates the live status indicators in the dashboard.

More importantly, I built strict teardown logic into the return cleanup function of the player's `useEffect`. When the component unmounts, `GestureManager.stop()` iterates over all active media stream tracks and calls `.stop()` on each one.

This guarantees that the laptop's green camera indicator light turns off immediately, camera hardware locks are released back to the operating system, and no memory leaks persist in the background.

If the user blocks camera permission, the promise rejection is caught, an error is logged, and the UI displays an amber status banner without crashing the application."

---

## F11: Semantic Gesture Command Mapping Architecture
*Spoken Depth: Small Feature (6 lines)*

"In designing the software architecture, I wanted to ensure our UI components weren't tightly coupled to Google MediaPipe's specific naming conventions.

In `gestureMap.js`, I created a dictionary that maps raw machine learning category strings to semantic player commands, like translating `OPEN_PALM` to `TogglePlay`, or `POINTING_UP` to `SeekForward`.

This architectural boundary adheres to the Dependency Inversion Principle. If we ever decide to replace MediaPipe with an Apple Vision framework or a custom-trained model with different label names, we only have to update this single mapping file instead of rewriting our player component.

I also structured `GestureCore.js` and `useGesture.js` as modular abstractions so other developers on the team could easily reuse gesture tracking across different components.

Currently, the mapping is defined statically. In a future update, I plan to build a settings modal allowing chefs to customize their own keybindings."

---

## F12: Dark-Themed Culinary Kitchen UI & Responsive Layout
*Spoken Depth: Small Feature (6 lines)*

"I designed the user interface specifically for the environment it lives in: a busy, steamy kitchen where a cook might be viewing a tablet propped up on a counter several feet away.

Using Tailwind CSS, I created an ultra-dark layout built around deep gray-950 backgrounds and high-contrast emerald-400 accents. This aesthetic minimizes screen glare and keeps the chef's visual focus locked on the video stream.

Below the player, I built a responsive five-column cheat sheet using CSS Grid that visually displays each supported hand gesture, its emoji, and what action it performs.

All interactive buttons and inputs are scaled generously with large hit targets so they can be tapped easily even if the chef chooses to touch the screen with a clean knuckle or stylus.

The layout is completely responsive, adapting seamlessly from small mobile screens to mounted kitchen tablets and large widescreen monitors.

In the future, I would like to add audio chime feedback so chefs know an action succeeded without having to look at the screen."

---

## Interview Rehearsal Checklist

Tick off each feature once you can speak its explanation fluently, without consulting notes, in under the targeted rehearsal time:

- [ ] **30-Second Elevator Pitch** *(Target: ~30 seconds)*
- [ ] **2-Minute Comprehensive Pitch** *(Target: ~120 seconds)*
- [ ] **F1: Edge AI Gesture Recognition Engine** *(Target: ~90 seconds)*
- [ ] **F2: Touchless Video Play / Pause Control** *(Target: ~45 seconds)*
- [ ] **F3: Precision Video Seeking (+/- 10s)** *(Target: ~45 seconds)*
- [ ] **F4: Interactive Frame Zoom (125% / 100%)** *(Target: ~45 seconds)*
- [ ] **F5: 1500ms Action Debounce & Cooldown Engine** *(Target: ~75 seconds)*
- [ ] **F6: Real-Time HUD Overlay & Live Gesture Indicators** *(Target: ~30 seconds)*
- [ ] **F7: Mirrored Vision Stream Inset Monitor & Toggle** *(Target: ~40 seconds)*
- [ ] **F8: Preset Recipe Stream Switcher** *(Target: ~30 seconds)*
- [ ] **F9: Custom Direct Video Stream / URL Ingestion** *(Target: ~35 seconds)*
- [ ] **F10: Hardware Camera Acquisition & Lifecycle Teardown** *(Target: ~75 seconds)*
- [ ] **F11: Semantic Gesture Command Mapping Architecture** *(Target: ~30 seconds)*
- [ ] **F12: Dark-Themed Culinary Kitchen UI & Responsive Layout** *(Target: ~30 seconds)*
