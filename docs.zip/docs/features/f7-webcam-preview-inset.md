# Feature F7: Mirrored Vision Stream Inset Monitor & Toggle

## 1. Feature Overview
Provides an optional, collapsible picture-in-picture webcam inset on the bottom-right corner of the video. It allows users to verify their framing, adjust room lighting, and confirm that their hand is properly inside the camera's field of view.

---

## 2. Technical Architecture & Flow

```mermaid
sequenceDiagram
    autonumber
    actor Chef
    participant Button as Inset Toggle Button
    participant State as showPreview (Boolean)
    participant Inset as Video Inset Element (-scale-x-100)

    Chef->>Button: Clicks "Show Camera Inset"
    Button->>State: setShowPreview(!showPreview)
    State->>Inset: opacity-100 & pointer-events-auto
    Chef->>Button: Clicks "Hide Camera Inset"
    Button->>State: setShowPreview(!showPreview)
    State->>Inset: opacity-0 & pointer-events-none
```

---

## 3. Files and Code Traces

- **Component JSX**: [src/components/ChefVideoPlayer.jsx:126-137](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L126-L137)
- **Toggle Control**: [src/components/ChefVideoPlayer.jsx:150-156](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L150-L156)

### Implementation Detail
```jsx
{/* Optional Webcam Preview Inset */}
<div className={`absolute bottom-16 right-4 w-40 aspect-video rounded-lg overflow-hidden border-2 border-emerald-500/50 shadow-lg bg-gray-950 transition-all ${showPreview ? "opacity-100" : "opacity-0 pointer-events-none"}`}>
  <video
    ref={hiddenCamRef}
    autoPlay
    playsInline
    muted
    className="w-full h-full object-cover -scale-x-100"
  />
  <div className="absolute bottom-1 left-1.5 text-[10px] bg-black/60 px-1.5 py-0.5 rounded text-white font-mono">
    Vision Feed
  </div>
</div>
```

---

## 4. Optical Mirroring (`-scale-x-100`)
Normal webcam streams display inverted coordinates relative to human self-perception (moving your right hand moves the left side of an unmirrored video). Applying Tailwind's `-scale-x-100` (`transform: scaleX(-1)`) flips the video horizontally like a bathroom mirror, creating an intuitive mental model for the chef.

---

## 5. Say It Out Loud (Spoken Explanation)

> "When using computer vision, users often don't know why a gesture isn't working—whether their hand is out of the camera's frame or if backlighting is washing out their silhouette.
>
> To solve this, I built an optional Picture-in-Picture webcam inset in the bottom-right corner of the player. Users can toggle it on or off with a single click on the control bar.
>
> In the code, I feed the same live `MediaStream` used by MediaPipe into this preview element, applying Tailwind's `-scale-x-100` utility to horizontally mirror the feed. This ensures when a chef moves their right hand, the preview behaves just like a natural mirror instead of an inverted webcam.
>
> By default, the inset is hidden using CSS opacity and `pointer-events-none`, keeping the video distraction-free once the chef is positioned comfortably.
>
> If the camera isn't active yet, the inset remains empty with a subtle emerald border.
>
> One improvement I'd like to add is rendering MediaPipe's skeletal hand landmarks directly on the inset canvas so users can see the neural network tracking their joints."
