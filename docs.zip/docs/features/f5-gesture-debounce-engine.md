# Feature F5: 1500ms Action Debounce & Cooldown Engine

## 1. Feature Overview
The Debounce & Cooldown Engine is the stability backbone of Touchless Chef. Because the webcam inference loop runs at 60 frames per second, a user holding an open palm for just half a second would generate 30 consecutive positive detections. Without throttling, this would cause the video player to rapidly toggle between play and pause 30 times in 500 milliseconds (the "stutter bug"). The Cooldown Engine enforces a 1500ms hysteresis buffer between command dispatches.

---

## 2. Technical Architecture & Timing Flow

```mermaid
sequenceDiagram
    autonumber
    participant Camera as Webcam (60 FPS)
    participant Model as MediaPipe (predictLoop)
    participant Timer as lastActionTime Ref
    participant Dispatcher as executeCommand()

    Note over Camera,Model: Frame 1 (t = 0ms)
    Camera->>Model: Hand enters frame (Open Palm)
    Model->>Timer: Check: (0 - 0) > 1500ms? -> TRUE
    Timer->>Dispatcher: executeCommand("Open_Palm")
    Dispatcher->>Timer: Set lastActionTime.current = 0ms

    Note over Camera,Model: Frame 2 to 89 (t = 16ms to 1484ms)
    Camera->>Model: Hand still present (Open Palm)
    Model->>Timer: Check: (t - 0) > 1500ms? -> FALSE
    Timer-->>Model: Suppress command (Cooldown active)

    Note over Camera,Model: Frame 90 (t = 1501ms)
    Camera->>Model: Hand still present or new gesture
    Model->>Timer: Check: (1501 - 0) > 1500ms? -> TRUE
    Timer->>Dispatcher: executeCommand(...)
    Dispatcher->>Timer: Set lastActionTime.current = 1501ms
```

---

## 3. Files and Code Traces

- **Ref Definition**: [src/components/ChefVideoPlayer.jsx:8](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L8)
- **Cooldown Check & Reset**: [src/components/ChefVideoPlayer.jsx:33-36](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L33-L36)

### Code Implementation
```javascript
// Line 8: Non-re-rendering mutable timestamp container
const lastActionTime = useRef(0);

// Line 31-36: Execution condition inside predictLoop
if (score > 0.75) {
  setActiveGesture(gesture);
  if (Date.now() - lastActionTime.current > 1500) {
    executeCommand(gesture);
    lastActionTime.current = Date.now();
  }
}
```

---

## 4. Why `useRef` Over `useState`
- **Re-render Isolation**: In React, updating a state variable triggers a component re-render. If `lastActionTime` were stored in `useState`, updating it every time a command fired would re-render the entire component tree, causing dropped video frames and garbage collection overhead.
- **Reference Immutability**: `useRef` provides a persistent mutable object whose `.current` property holds the timestamp across all animation frames without triggering DOM reconciliation.

---

## 5. Edge Cases Handled
1. **Initial Mount**: `lastActionTime` is initialized to `0`. `Date.now() - 0` is always greater than 1500, guaranteeing that the very first gesture detected executes immediately without any introductory lag.
2. **Clock Drift & Background Tabs**: Uses `Date.now()` (wall clock epoch time in milliseconds) rather than counting frame iterations. If the browser tab is throttled to 1 FPS when inactive, the 1500ms duration remains strictly accurate in real time.

---

## 6. Say It Out Loud (Spoken Explanation)

> "A critical engineering problem in real-time computer vision is the 'jitter and rapid trigger' dilemma: our camera and MediaPipe model process video at 60 frames every second. If a cook raises an open palm for just half a second, the model classifies that gesture 30 times consecutively. Without throttling, the player would violently toggle between play and pause 30 times in the blink of an eye.
>
> To solve this, I engineered an action cooldown engine using React's `useRef` to store the exact timestamp of the last executed command.
>
> In every animation frame of my `predictLoop`, once a gesture clears the 75 percent confidence hurdle, I calculate `Date.now() - lastActionTime.current`. If less than 1500 milliseconds have elapsed since the last command, the event is suppressed, while the visual HUD still updates to show the live detected gesture. Only when the 1.5-second cooldown window has passed does `executeCommand` fire and the timer resets to the current timestamp.
>
> I deliberately chose `useRef` instead of React `useState` because `useRef` allows me to mutate the timestamp synchronously across 60 FPS animation frames without triggering unnecessary React re-renders, which would otherwise drop video frames and degrade performance.
>
> If a user intentionally wants to skip forward multiple times quickly, they have to wait 1.5 seconds between skips.
>
> As a next step, I would implement adaptive cooldowns: a 1.5-second cooldown for play and pause toggles, but a shorter 500-millisecond cooldown for seeking, with support for gesture holds."
