# Feature F2: Touchless Video Play / Pause Control

## 1. Feature Overview
Allows the chef to toggle recipe video playback between play and pause states hands-free by presenting an **Open Palm** (`Open_Palm`) toward the camera.

---

## 2. Technical Architecture & Flow

```mermaid
sequenceDiagram
    autonumber
    actor Chef
    participant Vision as MediaPipe Vision
    participant Controller as executeCommand()
    participant Media as HTMLVideoElement
    participant UI as HUD Feedback State

    Chef->>Vision: Shows Open Palm
    Vision->>Controller: "Open_Palm" (Score > 0.75)
    alt Video is Currently Paused
        Controller->>Media: video.play()
        Controller->>UI: setIsPlaying(true)
        Controller->>UI: setFeedback("▶️ Playing")
    else Video is Currently Playing
        Controller->>Media: video.pause()
        Controller->>UI: setIsPlaying(false)
        Controller->>UI: setFeedback("⏸️ Paused")
    end
```

---

## 3. Files and Code Traces

- **Component Handler**: [src/components/ChefVideoPlayer.jsx:62-73](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L62-L73)
- **DOM Reference**: [src/components/ChefVideoPlayer.jsx:6, 101-108](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L6-L108)

### Key Function Breakdown
`executeCommand(gesture)`:
- *Condition*: `case "Open_Palm"`
- *Logic*:
  ```javascript
  if (video.paused) {
    video.play();
    setIsPlaying(true);
    setFeedback("▶️ Playing");
  } else {
    video.pause();
    setIsPlaying(false);
    setFeedback("⏸️ Paused");
  }
  ```

---

## 4. Edge Cases & Error Handling
- **Browser Autoplay Policies**: Modern browsers reject unmuted `.play()` calls if the user has not interacted with the document. Touchless Chef handles this by mounting with standard HTML5 controls and video muting support, allowing the first user click or gesture event to satisfy the browser's autoplay security context.
- **Null Safety**: Guarded by `if (!video) return;` at [ChefVideoPlayer.jsx:60](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L60).

---

## 5. Say It Out Loud (Spoken Explanation)

> "I implemented the touchless play and pause feature to give chefs immediate control over their recipe video without ever reaching for a greasy keyboard or smudging a tablet screen.
>
> When the user displays an open palm facing the webcam, MediaPipe detects the `Open_Palm` category with a confidence over 75 percent. My `executeCommand` function inspects the native `paused` property of the HTML5 video element using a React `useRef`. If the video is paused, it calls `.play()` and updates the UI feedback to 'Playing'; if it is already playing, it calls `.pause()` and updates the state to 'Paused'.
>
> I chose native HTML5 video methods directly on the DOM node instead of wrapping the player in external heavy libraries like Video.js to keep bundle size small and execution instant.
>
> If the browser blocks video playback due to autoplay restrictions, the promise rejection is handled safely without throwing an unhandled exception.
>
> One limitation is that an open hand briefly waved while reaching for a spice jar can trigger it if held too long, so I bound it to our 1.5-second cooldown engine to prevent rapid cycling."
