# Feature F1: Real-Time Edge AI Hand Gesture Recognition Engine

## 1. Feature Overview
The Real-Time Hand Gesture Recognition Engine is the central intelligence subsystem of Touchless Chef. It captures video frames from the user's webcam, evaluates hand landmarks, and classifies the current pose into recognized gesture categories at 60 frames per second using Google's **MediaPipe Vision Tasks** running on WebAssembly and WebGL.

---

## 2. Technical Architecture & Data Flow

```mermaid
flowchart TD
    A["Webcam Video Stream (640x480 @ 60fps)"] --> B["HTML5 Hidden Video Element"]
    B --> C["GestureManager.recognizer.recognizeVideo(video, timestamp)"]
    C --> D["WebAssembly Runtime (vision_wasm_internal)"]
    D --> E["WebGL / WebGPU Delegate (float16 Neural Net)"]
    E --> F["Landmark Extraction (21 3D Coordinates)"]
    F --> G["Hand Pose Classifier"]
    G --> H{"Confidence Score > 0.75?"}
    H -->|Yes| I["setActiveGesture(categoryName)"]
    H -->|No| J["setActiveGesture(null)"]
```

---

## 3. Files and Code Traces

- **Service Module**: [src/services/GestureManager.js:9-24](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureManager.js#L9-L24)
- **Component Controller**: [src/components/ChefVideoPlayer.jsx:15-56](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L15-L56)
- **Alternate Hook Service**: [src/services/GestureService.js:4-17](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureService.js#L4-L17)

### Key Function Breakdown
1. `FilesetResolver.forVisionTasks(wasmPath)`:
   - *Parameters*: CDN URL string (`https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm`).
   - *Return*: `Promise<VisionTasksResolver>`.
   - *Purpose*: Locates and fetches the WebAssembly binaries necessary to execute Google Vision models in the browser.
2. `GestureRecognizer.createFromOptions(vision, options)`:
   - *Parameters*:
     - `baseOptions.modelAssetPath`: `https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/1/gesture_recognizer.task`
     - `baseOptions.delegate`: `"GPU"`
     - `runningMode`: `"VIDEO"`
     - `numHands`: `1`
     - `minHandDetectionConfidence`: `0.7`
     - `minTrackingConfidence`: `0.7`
   - *Return*: `Promise<GestureRecognizer>`.
   - *Purpose*: Instantiates and compiles the quantized neural network on the client's GPU.
3. `GestureRecognizer.recognizeVideo(videoFrame, timestampMs)`:
   - *Parameters*: HTMLVideoElement, millisecond timestamp (`Date.now()`).
   - *Return*: `GestureRecognizerResult` containing `landmarks`, `worldLandmarks`, `handedness`, and `gestures` (`categoryName`, `score`).
   - *Purpose*: Evaluates a single video frame synchronously against the loaded model.

---

## 4. Edge Cases & Error Handling
- **Webcam Frame Readiness**: If the webcam stream has not yet buffered, `hiddenCamRef.current.readyState` will be $< 4$ (`HAVE_ENOUGH_DATA`). The loop checks `hiddenCamRef.current?.readyState === 4` before invoking inference, preventing DOM exceptions.
- **Low Confidence Filtering**: If the model detects a hand but confidence is $\le 0.75$, the gesture is dismissed as an accidental hand movement or background artifact.
- **Model Download Failures**: Wrapped in a `try/catch` block inside `setup()` ([ChefVideoPlayer.jsx:18-48](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L18-L48)), logging errors gracefully to the browser console.

---

## 5. Security & Performance
- **Zero Cloud Leakage**: Video frames are processed strictly in GPU memory buffers and are never serialized or sent over HTTP/WebSocket.
- **Memory Management**: The `requestAnimationFrame` loop ID (`animId`) is saved in closure scope and cancelled via `cancelAnimationFrame(animId)` on unmount ([ChefVideoPlayer.jsx:53](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L53)), preventing memory leaks and runaway CPU cycles.

---

## 6. Say It Out Loud (Spoken Explanation)

> "In this project, I built the core AI vision engine using Google MediaPipe's Vision Tasks, which runs a pre-trained gesture recognition neural network directly in the user's browser.
>
> When the video player component mounts, my `GestureManager` service fetches the WebAssembly runtime and the float16 quantized model bundle from Google's CDN, compiling the model onto the user's local GPU using WebGL. Once camera access is granted, I start a continuous `requestAnimationFrame` loop that feeds live 640-by-480 webcam frames into `recognizeVideo` along with high-resolution timestamps.
>
> For every frame, MediaPipe extracts 21 three-dimensional hand landmarks and classifies the pose. To prevent accidental triggers caused by kitchen utensils or background movements, I enforce a strict confidence threshold of 0.75 before accepting any gesture.
>
> I chose this client-side edge AI approach over a traditional Python FastAPI backend because streaming video over WebSockets or HTTP would introduce 200 to 400 milliseconds of latency, consume massive server bandwidth, and raise severe privacy concerns for home users.
>
> If the network drops or the CDN fails to serve the model bundle, the initialization promise rejects, gets caught in my error boundary, and the UI gracefully informs the chef while keeping standard manual controls intact.
>
> One current limitation is that it only tracks one hand at a time and requires reasonable kitchen lighting. If I were to improve it, I would add automatic exposure compensation and support multi-hand interactions."
