# Feature F12: Dark-Themed Culinary Kitchen UI & Responsive Layout

## 1. Feature Overview
A purpose-built, high-contrast dark user interface engineered with Tailwind CSS for high visibility in steam-filled or brightly lit professional kitchens, featuring mobile and tablet responsive layouts and Lucide React culinary iconography.

---

## 2. Technical Architecture & Responsive Layout Tree

```mermaid
flowchart TD
    subgraph Viewport["Responsive Screen (min-h-screen bg-gray-950)"]
        Header["Header: Logo, Title, CV AI Badge, Powered by MediaPipe Badge"]
        MainPlayer["ChefVideoPlayer: Video Stage, Floating Badges, Control Bar"]
        Switcher["Quick Video Switcher: Pill Buttons & Custom URL Form"]
        CheatSheet["Gesture Cheat Sheet: 5-Column Responsive Card Grid"]
    end

    Header --> MainPlayer
    MainPlayer --> Switcher
    Switcher --> CheatSheet
```

---

## 3. Files and Code Traces

- **Dashboard Layout**: [src/App.jsx:26-132](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/App.jsx#L26-L132)
- **Tailwind Directives**: [src/index.css:1-12](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/index.css#L1-L12)
- **Theme Config**: [tailwind.config.js:1-9](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/tailwind.config.js#L1-L9)

### Key Styling Tokens
- **Canvas Background**: `bg-gray-950` (`#030712`) — pure OLED black reducing eye strain and screen glare.
- **Accent Emeralds**: `emerald-400` (`#34d399`), `emerald-500` (`#10b981`), `emerald-600` (`#059669`) — high-contrast indicators that cut through kitchen steam.
- **Glassmorphic Panels**: `backdrop-blur-md`, `bg-black/70` for floating badges.
- **Grid Layout**: `grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3` for the gesture reference cards.

---

## 4. Accessibility & Visual Hierarchy
- **Icon + Label Pairing**: Every status element pairs a Lucide SVG icon (`UtensilsCrossed`, `Sparkles`, `Video`, `HelpCircle`, `Hand`) with clear text, ensuring colorblind accessibility.
- **Responsive Stacking**: Flex direction shifts from `flex-col` on mobile phones to `md:flex-row` on kitchen tablets and desktop monitors.

---

## 5. Say It Out Loud (Spoken Explanation)

> "I designed the user interface specifically for the environment it lives in: a busy, steamy kitchen where a cook might be viewing a tablet propped up on a counter several feet away.
>
> Using Tailwind CSS, I created an ultra-dark layout built around deep gray-950 backgrounds and high-contrast emerald-400 accents. This aesthetic minimizes screen glare and keeps the chef's visual focus locked on the video stream.
>
> Below the player, I built a responsive five-column cheat sheet using CSS Grid that visually displays each supported hand gesture, its emoji, and what action it performs.
>
> All interactive buttons and inputs are scaled generously with large hit targets so they can be tapped easily even if the chef chooses to touch the screen with a clean knuckle or stylus.
>
> The layout is completely responsive, adapting seamlessly from small mobile screens to mounted kitchen tablets and large widescreen monitors.
>
> In the future, I would like to add audio chime feedback so chefs know an action succeeded without having to look at the screen."
