# Feature F11: Semantic Gesture Command Mapping Architecture

## 1. Feature Overview
Decouples raw MediaPipe machine learning output strings (e.g. `Open_Palm`, `Thumb_Up`, `Victory`) from the playback controller logic using a semantic command abstraction layer, ensuring clean extensibility and future gesture customization.

---

## 2. Technical Architecture & Mapping Flow

```mermaid
flowchart LR
    A["Raw MediaPipe Output<br/>'Open_Palm'"] --> B["Command Dictionary<br/>gestureMap.js"]
    B --> C["Semantic Action<br/>'TogglePlay'"]
    C --> D["Playback Execution Engine<br/>ChefVideoPlayer.jsx"]
    D --> E["Native Media Action<br/>video.play() / video.pause()"]
```

---

## 3. Files and Code Traces

- **Mapping Constants**: [src/utils/gestureMap.js:1-7](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/utils/gestureMap.js#L1-L7)
- **Component Re-export**: [src/components/Gesture/GestureCore.js:1-3](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/Gesture/GestureCore.js#L1-L3)
- **Alternate Hook & Service**: [src/hooks/useGesture.js](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/hooks/useGesture.js), [src/services/GestureService.js](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureService.js)

### Constant Definition
```javascript
export const GESTURE_COMMANDS = {
  OPEN_PALM: 'TogglePlay',
  POINTING_UP: 'SeekForward',
  VICTORY: 'NextVideo',
  THUMB_UP: 'ZoomIn',
  THUMB_DOWN: 'ZoomOut'
};
```

---

## 4. Software Engineering Rationale
Without this separation, components would be tightly coupled to MediaPipe's exact naming conventions. If the underlying vision model is upgraded (for example, switching from MediaPipe to a custom TensorFlow.js model that outputs `open_hand` instead of `Open_Palm`), only `gestureMap.js` needs to be updated, leaving the core video playback controller untouched.

---

## 5. Say It Out Loud (Spoken Explanation)

> "In designing the software architecture, I wanted to ensure our UI components weren't tightly coupled to Google MediaPipe's specific naming conventions.
>
> In `gestureMap.js`, I created a dictionary that maps raw machine learning category strings to semantic player commands, like translating `OPEN_PALM` to `TogglePlay`, or `POINTING_UP` to `SeekForward`.
>
> This architectural boundary adheres to the Dependency Inversion Principle. If we ever decide to replace MediaPipe with an Apple Vision framework or a custom-trained model with different label names, we only have to update this single mapping file instead of rewriting our player component.
>
> I also structured `GestureCore.js` and `useGesture.js` as modular abstractions so other developers on the team could easily reuse gesture tracking across different components.
>
> Currently, the mapping is defined statically. In a future update, I plan to build a settings modal allowing chefs to customize their own keybindings."
