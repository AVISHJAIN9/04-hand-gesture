# Feature F9: Custom Direct Video Stream / URL Ingestion

## 1. Feature Overview
Allows chefs and instructors to paste any direct public MP4, WebM, or Ogg video URL into an input field on the dashboard to immediately practice gesture-controlled playback on their own instructional materials.

---

## 2. Technical Architecture & Flow

```mermaid
sequenceDiagram
    autonumber
    actor Chef
    participant Form as URL Ingestion Form
    participant State as setVideoUrl State
    participant Player as ChefVideoPlayer

    Chef->>Form: Enters "https://example.com/pasta-guide.mp4"
    Chef->>Form: Submits form (or presses Enter)
    Form->>Form: e.preventDefault() & customInput.trim()
    Form->>State: setVideoUrl(customInput)
    Form->>Form: setCustomInput('') (clears input)
    State->>Player: videoSrc prop changes to new URL
    Player->>Player: Video loads new stream
```

---

## 3. Files and Code Traces

- **Handler Logic**: [src/App.jsx:17-23](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/App.jsx#L17-L23)
- **Form JSX**: [src/App.jsx:78-93](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/App.jsx#L78-L93)

### Form Handling Code
```javascript
const handleCustomSubmit = (e) => {
  e.preventDefault();
  if (customInput.trim()) {
    setVideoUrl(customInput.trim());
    setCustomInput('');
  }
};
```

---

## 4. Input Sanitization & Resilience
- **Trimming Whitespace**: `.trim()` removes accidental leading or trailing spaces copied from web browsers.
- **Form Default Suppression**: `e.preventDefault()` halts full browser page reloads, preserving React application state and the active WebAssembly execution context.

---

## 5. Say It Out Loud (Spoken Explanation)

> "To make Touchless Chef truly practical for real-world cooking workshops, I built a custom video stream loader.
>
> Users can paste any direct MP4 or WebM video link into an input field below the player and click 'Load Video'. My `handleCustomSubmit` function intercepts the form submission, prevents the default browser reload, sanitizes the URL by trimming whitespace, and updates the application's root `videoUrl` state.
>
> This gives instructors the flexibility to load their own recipe tutorials or workshop recordings directly from cloud storage buckets or content delivery networks.
>
> Because the form is built with controlled React inputs, the text field clears automatically upon submission for a clean user experience.
>
> If a user enters an invalid or unreachable video link, the browser's video element displays standard error indicators without crashing the JavaScript runtime.
>
> In the next release, I'd like to add local drag-and-drop file support using the HTML5 File API so users can play offline video files without needing to host them online."
