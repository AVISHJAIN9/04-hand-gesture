# Feature F10: Hardware Camera Acquisition & Lifecycle Teardown

## 1. Feature Overview
Responsible for negotiating hardware permissions with the browser, streaming live video from the user's webcam at 640x480 resolution, and gracefully terminating hardware tracks upon component unmounting to prevent camera indicator lockup and battery drainage.

---

## 2. Technical Architecture & Lifecycle State Machine

```mermaid
stateDiagram-v2
    [*] --> Idle: Application Mounts
    Idle --> RequestingPermission: navigator.mediaDevices.getUserMedia()
    RequestingPermission --> PermissionDenied: User clicks "Block" or no hardware
    RequestingPermission --> StreamActive: User clicks "Allow"
    
    state StreamActive {
        VideoTrackStreaming: 640x480 user-facing video
        AssignSrcObject: videoElement.srcObject = stream
    }
    
    StreamActive --> HardwareReleased: Component unmounts (useEffect cleanup)
    
    state HardwareReleased {
        StopTracks: stream.getTracks().forEach(track => track.stop())
        CameraLightOff: Hardware LED turns off
    }
    
    HardwareReleased --> [*]
```

---

## 3. Files and Code Traces

- **Service Module**: [src/services/GestureManager.js:26-43](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureManager.js#L26-L43)
- **Component Lifecycle Integration**: [src/components/ChefVideoPlayer.jsx:20-22, 54](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L20-L54)

### Method Implementations
```javascript
// Stream Acquisition (GestureManager.js:26-37)
async startCamera(videoElement) {
  try {
    this.stream = await navigator.mediaDevices.getUserMedia({ 
      video: { width: 640, height: 480, facingMode: "user" } 
    });
    videoElement.srcObject = this.stream;
    return true;
  } catch (err) {
    console.error("Chef denied camera access:", err);
    return false;
  }
}

// Track Termination & Teardown (GestureManager.js:39-43)
stop() {
  if (this.stream) {
    this.stream.getTracks().forEach(track => track.stop());
  }
}
```

---

## 4. Hardware Teardown Integrity
In single-page applications, failing to terminate active media tracks when navigating away or unmounting components is a notorious bug:
1. The laptop's green camera LED stays illuminated, causing user privacy panic.
2. The operating system's camera driver remains locked, preventing other applications from accessing the webcam.
3. The browser keeps background memory buffers active, creating memory leaks.

Touchless Chef resolves this in [ChefVideoPlayer.jsx:54](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L54) by returning a cleanup function in `useEffect` that calls `GestureManager.stop()`.

---

## 5. Say It Out Loud (Spoken Explanation)

> "Managing hardware lifecycles properly in browser applications is something junior developers often overlook. In Touchless Chef, I encapsulated webcam acquisition and resource cleanup inside my `GestureManager` singleton.
>
> When the player mounts, `startCamera` requests user permission via `navigator.mediaDevices.getUserMedia`, constraining the stream to 640-by-480 resolution with a front-facing camera preference. This resolution provides the optimal balance between high landmark tracking accuracy and low GPU memory bandwidth.
>
> Once permission is granted, I attach the stream directly to the video element's `srcObject` property and return true, which activates the live status indicators in the dashboard.
>
> More importantly, I built strict teardown logic into the return cleanup function of the player's `useEffect`. When the component unmounts, `GestureManager.stop()` iterates over all active media stream tracks and calls `.stop()` on each one.
>
> This guarantees that the laptop's green camera indicator light turns off immediately, camera hardware locks are released back to the operating system, and no memory leaks persist in the background.
>
> If the user blocks camera permission, the promise rejection is caught, an error is logged, and the UI displays an amber status banner without crashing the application."
