# Feature F8: Preset Recipe Stream Switcher

## 1. Feature Overview
Provides a curated set of preset video streams—including high-definition cooking and instructional demonstration clips—accessible via pill buttons on the dashboard for instant, zero-setup testing.

---

## 2. Technical Architecture & Flow

```mermaid
flowchart LR
    A["User clicks 'Kitchen Recipe Clip' button"] --> B["setVideoUrl(vid.url) in App.jsx"]
    B --> C["Pass new videoSrc prop to ChefVideoPlayer"]
    C --> D["HTML5 Video Player updates src without unmounting"]
    D --> E["MediaPipe Vision Loop remains active continuously"]
```

---

## 3. Files and Code Traces

- **State & Data Setup**: [src/App.jsx:6-15](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/App.jsx#L6-L15)
- **UI Render**: [src/App.jsx:62-76](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/App.jsx#L62-L76)

### Sample Video Configuration
```javascript
const sampleVideos = [
  { name: 'Demo Video (Nature)', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' },
  { name: 'Kitchen Recipe Clip', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4' },
  { name: 'Tech Showcase', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4' },
];
```

---

## 4. Lifecycle Decoupling
Because `ChefVideoPlayer` receives `videoSrc` as a prop and keeps its MediaPipe vision recognizer in a persistent `useEffect` closure ([ChefVideoPlayer.jsx:15-56](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L15-L56)), changing video streams never interrupts camera capture or requires reloading the 5.6MB model bundle.

---

## 5. Say It Out Loud (Spoken Explanation)

> "To make the application instantly usable without requiring users to find and upload their own video files, I built an interactive preset recipe switcher.
>
> In `App.jsx`, I maintain a curated array of high-definition video streams hosted on Google Cloud Storage, including culinary recipe clips and nature demos. When the user clicks any of the preset buttons, React updates the `videoUrl` state, which flows down as a prop into `ChefVideoPlayer`.
>
> Crucially, because my computer vision tracking loop is decoupled from the video source URL, switching recipes updates the video stream immediately without re-initializing the MediaPipe model or dropping the webcam connection.
>
> The active video button is highlighted with an emerald border and subtle glow so the user always knows which stream is loaded.
>
> If a video fails to stream due to CORS or network issues, the HTML5 video element surfaces its native error state.
>
> In the future, I would like to connect this switcher to a YouTube or Vimeo API to let users search real culinary channels directly."
