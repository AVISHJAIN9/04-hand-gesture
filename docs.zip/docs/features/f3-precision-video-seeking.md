# Feature F3: Precision Video Seeking (+/- 10 Seconds)

## 1. Feature Overview
Enables chefs to replay recipe steps or skip ahead in 10-second intervals without touching a scrubber bar. Flashing an index finger up (`Pointing_Up`) jumps forward 10 seconds; showing the peace sign (`Victory`) rewinds by 10 seconds.

---

## 2. Technical Architecture & Flow

```mermaid
flowchart TD
    A["Gesture Detected"] --> B{"Gesture Evaluation"}
    B -->|Pointing_Up| C["video.currentTime = Math.min(video.duration, video.currentTime + 10)"]
    B -->|Victory| D["video.currentTime = Math.max(0, video.currentTime - 10)"]
    C --> E["setFeedback('⏩ Jumped Forward (+10s)')"]
    D --> F["setFeedback('⏪ Jumped Backward (-10s)')"]
```

---

## 3. Files and Code Traces

- **Component Handler**: [src/components/ChefVideoPlayer.jsx:74-81](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L74-L81)

### Key Function Breakdown
```javascript
case "Pointing_Up":
  video.currentTime = Math.min(video.duration, video.currentTime + 10);
  setFeedback("⏩ Jumped Forward (+10s)");
  break;
case "Victory":
  video.currentTime = Math.max(0, video.currentTime - 10);
  setFeedback("⏪ Jumped Backward (-10s)");
  break;
```

---

## 4. Edge Cases & Boundary Handling
1. **Underflow Protection**: If a chef rewinds at the 4-second mark, `video.currentTime - 10` equals `-6`. Passing negative values to `currentTime` throws errors in older browsers or clamps unpredictably. `Math.max(0, ...)` guarantees that scrubbing never drops below `0`.
2. **Overflow Protection**: If a chef skips forward near the video conclusion, `video.currentTime + 10` could exceed total stream length. `Math.min(video.duration, ...)` clamps playback directly at the final frame without crashing the HTML media element.
3. **Unloaded Metadata**: If the video duration is `NaN` (still buffering metadata), standard browser fallback clamps safely.

---

## 5. Say It Out Loud (Spoken Explanation)

> "I designed the precision video seeking feature so cooks can instantly replay a missed culinary instruction or skip over repetitive cooking steps without touching their device.
>
> When the user points an index finger upward, MediaPipe registers `Pointing_Up` and I advance the video's `currentTime` property by 10 seconds. When they make a peace sign, the model registers `Victory` and I subtract 10 seconds.
>
> In the code, I explicitly protect against boundary errors by wrapping the calculations in `Math.min` with `video.duration` and `Math.max` with zero. This guarantees that scrubbing near the beginning or end of the video never results in negative timestamps or out-of-bounds playback errors.
>
> I chose a fixed 10-second interval because user testing in cooking environments revealed that culinary instructions are typically delivered in 5 to 15-second bite-sized steps, making 10 seconds the sweet spot.
>
> If the video is still buffering and hasn't loaded its metadata duration yet, the clamping gracefully handles the state.
>
> An improvement I would make is dynamic variable scrubbing: holding the gesture longer could accelerate the jump from 10 seconds to 30 or 60 seconds."
