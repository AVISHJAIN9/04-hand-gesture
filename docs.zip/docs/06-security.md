# Step 7: Security Audit & Threat Modeling (OWASP Top 10)

## 1. Security Architecture Summary
Touchless Chef possesses an inherently defensive security posture because it operates **100% on the client side**. Without a traditional backend database or user session store, the attack surface related to server-side SQL injection, session hijacking, or database credential theft is completely eliminated. 

However, client-side computer vision introduces unique security considerations: camera permission management, Cross-Site Scripting (XSS) via custom URL inputs, Content Security Policy (CSP) configurations for WebAssembly, and local hardware resource exhaustion.

---

## 2. OWASP Top 10 Mapping & Project Evaluation

| OWASP Threat Category | Applicability to Touchless Chef | Implemented Defenses | Vulnerabilities / Missing Controls | Interviewer Attack Angle |
| :--- | :--- | :--- | :--- | :--- |
| **A01: Broken Access Control** | **Not Applicable (Client App)** | No multi-tenant backend or role-based access control. | No server authorization checks. | "Can a user access another user's camera feed?" (No, streams are local only). |
| **A02: Cryptographic Failures** | **Medium** | Camera streams require HTTPS / localhost encryption under WebRTC specifications. | Zero client-side storage encryption (state is ephemeral). | "Can unencrypted HTTP sites access the user's webcam?" |
| **A03: Injection** | **High** | React automatically escapes JSX expressions, preventing direct DOM script execution. | Custom video URL input accepts any URI schema without strict regex protocol validation (`javascript:` attack vector). | "Can an attacker inject malicious URLs or SVG payloads into the custom loader?" |
| **A04: Insecure Design** | **Low** | Strict 1500ms cooldown engine prevents rapid actuation denial-of-service. | No rate limiting on custom URL loading. | "Can rapid video switching crash the browser tab?" |
| **A05: Security Misconfiguration**| **High** | Production build removes sourcemaps and debug flags. | Missing strict Content Security Policy (`script-src`, `wasm-unsafe-eval`, `connect-src`). | "Why does MediaPipe require `wasm-unsafe-eval` in CSP headers?" |
| **A06: Vulnerable Components** | **Medium** | Modern dependencies pinned in `package.json` and locked in `package-lock.json`. | Relies on third-party public CDNs (JSDelivr) for WASM runtime. | "What happens if JSDelivr is compromised via a supply-chain attack?" |
| **A07: Identification & Auth** | **Not Applicable** | No login, signup, or JWT tokens. | None (Sessionless utility). | "How would you secure authentication if you added accounts?" |
| **A08: Software & Data Integrity**| **High** | Pre-trained model downloaded over TLS. | No Subresource Integrity (SRI) hashes applied to the dynamically fetched `.task` bundle. | "Could an in-flight proxy tamper with the gesture weights to alter gesture triggers?" |
| **A09: Logging & Monitoring** | **Low** | Console error logging for camera and gesture tracking failures. | No centralized telemetry (Sentry/Datadog) for production client crashes. | "How do you know if users encounter camera failures in the wild?" |
| **A10: Server-Side Request Forgery**| **Not Applicable** | Zero server-side request proxies exist. | None. | "Can custom video URLs trigger SSRF?" (No, requests originate from client). |

---

## 3. Deep-Dive Security Topics

### 1. Camera Permissions & Privacy Integrity
- **Browser Sandbox Guarantee**: The webcam cannot be turned on silently. Under the W3C Media Capture specification, `navigator.mediaDevices.getUserMedia` requires explicit user consent via browser permission prompts.
- **Hardware Light Verification**: Hardware teardown in `GestureManager.stop()` ([GestureManager.js:39-43](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureManager.js#L39-L43)) terminates media tracks, preventing the camera hardware from remaining energized after unmount.

```mermaid
sequenceDiagram
    autonumber
    actor Attacker
    participant Browser as Browser Security Sandbox
    participant App as Touchless Chef
    participant Camera as Physical Webcam

    Attacker->>App: Attempts to silently trigger camera
    App->>Browser: getUserMedia()
    Browser-->>Attacker: Halts! Displays mandatory User Permission Modal
    Note over Browser: If user rejects, camera access is permanently denied.
```

### 2. URL Ingestion & Cross-Site Scripting (XSS) Vector
In [src/App.jsx:78-93](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/App.jsx#L78-L93), users can paste custom video links:
```javascript
// Current Implementation:
if (customInput.trim()) {
  setVideoUrl(customInput.trim());
}
```
- **Vulnerability**: If an attacker tricks a user into entering `javascript:alert(document.cookie)`, assigning it to an `href` would trigger XSS.
- **Defense in Touchless Chef**: Because the URL is passed strictly to the `<video src={videoUrl}>` attribute in React, modern browsers do NOT execute `javascript:` URIs inside media tags; instead, the video element fires an error event (`MEDIA_ELEMENT_ERROR`).
- **Recommended Hardening**: Implement strict protocol validation ensuring URLs strictly match `^https?://`:
  ```javascript
  const isValidUrl = (url) => {
    try {
      const parsed = new URL(url);
      return ['http:', 'https:'].includes(parsed.protocol);
    } catch {
      return false;
    }
  };
  ```

### 3. Content Security Policy (CSP) Configuration
Because MediaPipe Vision Tasks executes compiled WebAssembly and fetches binary task bundles, hosting servers must define a tailored CSP:

```http
Content-Security-Policy: 
  default-src 'self';
  script-src 'self' 'wasm-unsafe-eval' https://cdn.jsdelivr.net;
  connect-src 'self' https://cdn.jsdelivr.net https://storage.googleapis.com;
  media-src 'self' https://commondatastorage.googleapis.com blob: data:;
  img-src 'self' data: blob:;
  style-src 'self' 'unsafe-inline';
```

> [!IMPORTANT]
> The `'wasm-unsafe-eval'` directive is mandatory for WebAssembly runtimes in modern browsers. It allows WebAssembly memory allocation and compilation while still blocking standard insecure JavaScript `eval()` strings.

---

## 4. AI Security: Adversarial Machine Learning & Injection
- **No LLM Prompt Injection Risk**: Because Touchless Chef uses a **Computer Vision Classifier** rather than a Large Language Model (like GPT-4 or Claude), standard text prompt injection attacks are completely impossible.
- **Adversarial Physical Attacks**: In computer vision, adversarial attacks take the form of physical perturbations (e.g., an adversarial patterned apron designed to trick the neural net into detecting continuous `Thumb_Up` commands).
  - *Mitigation*: Our strict `score > 0.75` confidence threshold combined with the 1500ms cooldown engine successfully filters out noisy, transient classification spikes.
