# Step 1: Project Map & Technology Inventory

## 1. Complete Repository Folder Tree

```text
HandGestureCV-Clean-Project/
├── .git/                                # Git version control metadata and commit trajectory
├── .gitignore                           # Git ignore specification (node_modules, dist, etc.)
├── docs/                                # Complete comprehensive interview-ready technical documentation
├── index.html                           # HTML5 root entry point mounting React root container
├── install.bat                          # Windows one-click batch script for npm dependency installation
├── start.bat                            # Windows one-click batch script launching Vite dev server
├── package.json                         # Project dependencies, scripts, and package metadata
├── package-lock.json                    # Deterministic NPM dependency lockfile
├── postcss.config.js                    # PostCSS pipeline configuration for Tailwind and Autoprefixer
├── tailwind.config.js                   # Tailwind CSS content scanner and styling theme rules
├── vite.config.js                       # Vite bundler configuration (React plugin, port 5173, host exposure)
├── README.md                            # High-level repository overview and quick start instructions
└── src/                                 # Primary application source code directory
    ├── App.jsx                          # Main UI dashboard: header, recipe switcher, custom URL loader, gesture guide
    ├── index.css                        # Global CSS stylesheet importing Tailwind directives and baseline body styles
    ├── main.jsx                         # React 18 client entry point initializing ReactDOM.createRoot
    ├── components/                      # Reusable UI presentation and playback components
    │   ├── ChefVideoPlayer.jsx          # Core player component: video element, gesture prediction loop, HUD badges
    │   └── Gesture/                     # Modular gesture component namespace
    │       └── GestureCore.js           # Re-export bridge module for backward-compatible component imports
    ├── hooks/                           # Custom React hooks
    │   └── useGesture.js                # Custom hook encapsulating MediaPipe animation frame detection loop
    ├── services/                        # Edge AI computer vision and camera services
    │   ├── GestureManager.js            # Singleton class managing WASM model loading, camera stream, and cleanup
    │   └── GestureService.js            # Alternate service initializer for custom hook integration
    └── utils/                           # Shared utility mappings and constants
        └── gestureMap.js                # Semantic dictionary mapping gesture raw labels to player commands
```

---

## 2. Technology Stack & Exact Versions

| Layer / Role | Technology | Exact Version in `package.json` | Purpose in Project |
| :--- | :--- | :--- | :--- |
| **Frontend Framework** | **React** | `^18.3.1` | Declarative UI rendering, state management, and ref lifecycle hooks. |
| **DOM Renderer** | **React DOM** | `^18.3.1` | Mounts React virtual DOM into the browser's native DOM tree. |
| **Edge AI / Vision Tasks** | **@mediapipe/tasks-vision** | `^0.10.14` | Official Google MediaPipe WebAssembly vision engine for on-device gesture recognition. |
| **UI Iconography** | **lucide-react** | `^0.441.0` | High-performance, tree-shakeable SVG icons (`Hand`, `UtensilsCrossed`, `Video`, etc.). |
| **Build Tool & Bundler** | **Vite** | `^5.4.11` | Ultra-fast ESM development server, HMR, and production Rollup bundler. |
| **React Vite Plugin** | **@vitejs/plugin-react** | `^4.3.3` | Babel-based Fast Refresh and JSX transformation pipeline. |
| **Utility CSS Framework** | **Tailwind CSS** | `^3.4.15` | Rapid, atomic CSS class generation for responsive dark-themed styling. |
| **CSS Post-Processor** | **PostCSS** | `^8.4.49` | Tool for transforming styles with JS plugins. |
| **CSS Vendor Prefixing**| **Autoprefixer** | `^10.4.20` | Automatically appends vendor prefixes to CSS properties for cross-browser support. |

---

## 3. Dependency Inventory & Justifications

### Production Dependencies (`dependencies`)
1. **`@mediapipe/tasks-vision` (`^0.10.14`)**:  
   *Reason*: Provides the WebAssembly runtime (`FilesetResolver`) and high-level vision pipeline (`GestureRecognizer`) that downloads, parses, and executes Google's quantized neural network on live video frames using browser WebGL/WebGPU acceleration.
2. **`lucide-react` (`^0.441.0`)**:  
   *Reason*: Clean, modern SVG icon library that visually guides chefs on camera status, feedback states, video controls, and gesture instructions.
3. **`react` (`^18.3.1`)**:  
   *Reason*: Foundation UI engine providing the reconciliation loop, reactive state (`useState`), and mutable DOM refs (`useRef`).
4. **`react-dom` (`^18.3.1`)**:  
   *Reason*: Bridges React virtual elements to real browser HTML elements (`<video>`, `<div>`, `<button>`).

### Development Dependencies (`devDependencies`)
1. **`@vitejs/plugin-react` (`^4.3.3`)**:  
   *Reason*: Enables React 18 JSX transform and instant Hot Module Replacement during development.
2. **`autoprefixer` (`^10.4.20`)**:  
   *Reason*: Guarantees that CSS transforms (`scale(1.25)`) and flex/grid rules work consistently across Safari, Chrome, Edge, and Firefox.
3. **`postcss` (`^8.4.49`)**:  
   *Reason*: Required CSS build-time engine to compile Tailwind utility classes into pure CSS.
4. **`tailwindcss` (`^3.4.15`)**:  
   *Reason*: Powers the dark-themed culinary visual aesthetic with zero manual CSS boilerplate.
5. **`vite` (`^5.4.11`)**:  
   *Reason*: Replaces slow Webpack bundlers with lightning-fast native ES modules and optimized Rollup production builds.

---

## 4. Environment Variables & Secrets Audit

| Variable Name | Required Service | Purpose | Where Read in Code | Where to Obtain |
| :--- | :--- | :--- | :--- | :--- |
| *None* | *None* | *Not applicable* | *Zero env variables* | No API keys needed. The model weights and WASM packages are open-source and served via public Google Storage & JSDelivr CDNs. |

> [!NOTE]
> Unlike typical AI projects that rely on paid OpenAI or Anthropic API keys that risk leaking from frontend bundles, Touchless Chef runs an **entirely on-device edge model**. No credentials, tokens, or environment files (`.env`) are required to run or deploy the application.

---

## 5. Third-Party Services & External CDNs

1. **JSDelivr CDN (`cdn.jsdelivr.net`)**:
   - *Asset*: `@mediapipe/tasks-vision@latest/wasm`
   - *Usage*: Resolves WASM binaries (`vision_wasm_internal.js`, `.wasm`) dynamically on startup.
2. **Google Cloud Storage Model Bucket (`storage.googleapis.com/mediapipe-models`)**:
   - *Asset*: `gesture_recognizer.task` (float16 quantized bundle)
   - *Usage*: Fetches the neural network weights and label classification maps.
3. **Google GTV Video Bucket (`commondatastorage.googleapis.com/gtv-videos-bucket`)**:
   - *Asset*: Sample MP4 video files (`BigBuckBunny.mp4`, `ForBiggerBlazes.mp4`, `ElephantsDream.mp4`)
   - *Usage*: Supplies high-definition culinary and nature streams for immediate testing.

---

## 6. System Entry Points

- **HTML Entry Point**: [index.html](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/index.html) (HTML5 doctype, UTF-8 meta, root container, module script reference to `/src/main.jsx`).
- **JavaScript Entry Point**: [src/main.jsx](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/main.jsx) (mounts `<App />` inside `React.StrictMode`).
- **UI Root Component**: [src/App.jsx](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/App.jsx) (orchestrates header, recipe selector, custom video loader, and player).
- **Backend Entry Point**: *Not applicable for this project type*.
- **One-Click Automation Scripts**:
  - [install.bat](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/install.bat): Executes `npm install --legacy-peer-deps`.
  - [start.bat](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/start.bat): Executes `npm run dev`.
