# Touchless Chef: Complete Documentation Index

Welcome to the comprehensive, interview-ready technical documentation set for **Touchless Chef (`hand-gesture-cv`)**. Designed in the clean, step-by-step style of the **Vue.js documentation**, this documentation enables a developer to read through once and confidently answer any technical question an interviewer could ask.

---

## Complete Reading Order

### 0. Project Genesis & Ground Truth
1. [**00-project-type.md**](./00-project-type.md) — Step 0 Pre-Check: Concrete project classification (**Type B: Frontend-Only Edge AI SPA**).
2. [**00a-project-analysis.md**](./00a-project-analysis.md) — Step 0 Full Project Analysis: End-to-end tracing of all features, APIs, hooks, connections, and inventory counts.
3. [**00b-project-pitch.md**](./00b-project-pitch.md) — 30-Second Elevator Pitch & 2-Minute Comprehensive Interview Pitch.
4. [**00-project-map.md**](./00-project-map.md) — Step 1 Project Map: Directory tree, tech stack versions, dependencies, and environment audit.

---

### 1. Feature Specifications & Spoken Rehearsal
5. [**01-features.md**](./01-features.md) — Step 2 Feature Inventory Index & Architecture Interaction Diagram.
   - [**F1: Real-Time Edge AI Hand Gesture Recognition Engine**](./features/f1-gesture-recognition-engine.md)
   - [**F2: Touchless Video Play / Pause Control**](./features/f2-touchless-video-control.md)
   - [**F3: Precision Video Seeking (+/- 10 Seconds)**](./features/f3-precision-video-seeking.md)
   - [**F4: Interactive Frame Zoom & Inspection (125% / 100%)**](./features/f4-interactive-frame-zoom.md)
   - [**F5: 1500ms Action Debounce & Cooldown Engine**](./features/f5-gesture-debounce-engine.md)
   - [**F6: Real-Time HUD Overlay & Live Gesture Indicators**](./features/f6-visual-feedback-hud.md)
   - [**F7: Mirrored Vision Stream Inset Monitor & Toggle**](./features/f7-webcam-preview-inset.md)
   - [**F8: Preset Recipe Stream Switcher**](./features/f8-recipe-video-switcher.md)
   - [**F9: Custom Direct Video Stream / URL Ingestion**](./features/f9-custom-video-loader.md)
   - [**F10: Hardware Camera Acquisition & Lifecycle Teardown**](./features/f10-camera-lifecycle-manager.md)
   - [**F11: Semantic Gesture Command Mapping Architecture**](./features/f11-gesture-mapping-abstraction.md)
   - [**F12: Dark-Themed Culinary Kitchen UI & Responsive Layout**](./features/f12-dark-mode-culinary-ui.md)
6. [**14-say-it-out-loud.md**](./14-say-it-out-loud.md) — Step 2.5 Master Spoken Interview Rehearsal Guide & Rehearsal Checklist.

---

### 2. Engineering Blueprints & Technical Audits
7. [**02-build-order.md**](./02-build-order.md) — Step 3 Build Order: Sequential guide to rebuilding the application from scratch with line-by-line code explanations.
8. [**03-api-reference.md**](./03-api-reference.md) — Step 4 API Reference: Client service APIs, external CDNs, and backend theoretical contracts.
9. [**04-tech-comparisons.md**](./04-tech-comparisons.md) — Step 5 Exhaustive Tech Choice Comparisons: MediaPipe vs TensorFlow.js, React vs Vue/Svelte, Tailwind vs CSS-in-JS, and `useRef` hysteresis vs Lodash debounce.
10. [**05-architecture.md**](./05-architecture.md) — Step 6 Architecture & System Design: Request lifecycles, data flow diagrams, caching layers, and 100x bottlenecks.
11. [**06-security.md**](./06-security.md) — Step 7 Security Audit: OWASP Top 10 mapping, camera permissions, and WebAssembly Content Security Policy.
12. [**07-ai-integration.md**](./07-ai-integration.md) — Step 8 Edge AI Deep Dive: BlazePalm detector, 21 3D landmarks, float16 quantization, and buy vs build analysis.
13. [**08-quality-and-ops.md**](./08-quality-and-ops.md) — Step 9 DevOps & Operations: Git commit trajectory, automated test pyramid, deployment configs, and technical debt.

---

### 3. Interview Mastery & Verification Manifests
14. [**09-interview-qa.md**](./09-interview-qa.md) — Step 10 Master Interview Preparation Guide: **155 comprehensive questions and answers** covering all technical topics.
15. [**10-gaps-and-improvements.md**](./10-gaps-and-improvements.md) — Step 11 Prioritized Engineering Gaps & Production Enhancements.
16. [**11-glossary.md**](./11-glossary.md) — Step 12 Technical Glossary: Alphabetical definitions of all project concepts.
17. [**12-confirm-list.md**](./12-confirm-list.md) — Step 12 Developer Confirmation Checklist (`[CONFIRM WITH DEVELOPER]`).
18. [**13-master-checklist.md**](./13-master-checklist.md) — Step 13 Master Checklist: All **275 items** audited under the 7-part framework with final coverage table.

---

### 4. System Design Deep Dive (18 Chapters)
19. [**system-design/README.md**](./system-design/README.md) — System Design Index.
    - [**14.1: Requirements & Capacity Estimation**](./system-design/14.1-requirements-and-estimation.md)
    - [**14.2: Architecture Styles (Edge SPA vs Microservices)**](./system-design/14.2-architecture-styles.md)
    - [**14.3: Networking & Communication Protocols**](./system-design/14.3-networking-and-communication.md)
    - [**14.4: Load Balancing & Scaling Strategy**](./system-design/14.4-load-balancing-and-scaling.md)
    - [**14.5: Databases & Storage Architecture**](./system-design/14.5-databases-and-storage.md)
    - [**14.6: Caching Strategies Across Layers**](./system-design/14.6-caching.md)
    - [**14.7: Messaging, Queues & Async Processing**](./system-design/14.7-messaging-and-async.md)
    - [**14.8: Consistency, Concurrency & Hysteresis**](./system-design/14.8-consistency-and-concurrency.md)
    - [**14.9: Reliability & Resilience Engineering**](./system-design/14.9-reliability-and-resilience.md)
    - [**14.10: API Design & Client-Side Rate Limiting**](./system-design/14.10-api-design-and-rate-limiting.md)
    - [**14.11: Security Architecture & Threat Defense**](./system-design/14.11-security-architecture.md)
    - [**14.12: Search & Edge AI Architecture**](./system-design/14.12-search-and-ai-architecture.md)
    - [**14.13: Real-Time Systems & Media Streams**](./system-design/14.13-real-time-systems.md)
    - [**14.14: Observability & Operational Excellence**](./system-design/14.14-observability-and-operations.md)
    - [**14.15: Performance Engineering & Latency Budget**](./system-design/14.15-performance-engineering.md)
    - [**14.16: Financial Cost Analysis & Architectural Trade-offs**](./system-design/14.16-cost-and-trade-offs.md)
    - [**14.17: Classic System Design Problems Applied**](./system-design/14.17-classic-system-design-applied.md)
    - [**14.18: Design Decisions Log (ADR Matrix)**](./system-design/decisions.md)
