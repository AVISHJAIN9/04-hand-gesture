# Step 0 Pre-Check: Project Type Detection

## 1. Project Type Determination

Based on exhaustive analysis of the codebase, `package.json`, configuration files, and imports, **Touchless Chef (HandGestureCV-Clean-Project)** is classified under:

> **TYPE B: Frontend Only (Client-Side Computer Vision Single-Page Application)**  
> *With integrated pre-trained edge AI model via `@mediapipe/tasks-vision` executing in-browser through WebAssembly (WASM) and WebGL GPU acceleration.*

---

## 2. Concrete Evidence from Codebase

| Evidence Category | File / Artifact | Exact Code / Dependency Match | Verification & Purpose |
| :--- | :--- | :--- | :--- |
| **Frontend Framework** | `package.json:15-16` | `"react": "^18.3.1"`, `"react-dom": "^18.3.1"` | Pure React 18 client-side rendering. |
| **Bundler & Tooling** | `package.json:23`, `vite.config.js:1-12` | `"vite": "^5.4.11"`, `@vitejs/plugin-react` | Vite dev server running on port 5173 with hot-module replacement. No backend server files (`server.js`, `app.js`, Express, Fastify). |
| **Edge AI / CV Engine** | `package.json:13`, `src/services/GestureManager.js:1` | `"@mediapipe/tasks-vision": "^0.10.14"` | Client-side Google MediaPipe Gesture Recognizer loaded dynamically via WASM binaries. |
| **UI & Styling** | `package.json:20-22`, `tailwind.config.js:1-9` | `"tailwindcss": "^3.4.15"`, `autoprefixer`, `postcss` | Utility-first styling with zero runtime server-side template generation. |
| **Icons** | `package.json:14` | `"lucide-react": "^0.441.0"` | Client-side SVG iconography. |
| **No Server Files** | Project Root | Absence of `server.js`, `routes/`, `controllers/`, `express`, `mongoose` | No backend API or server-side runtime exists. |
| **No Database** | Project Root | No connection strings, no MongoDB/SQL drivers, no ORM/ODM | Videos are streamed directly from Google Storage CDN or custom client URLs. |

---

## 3. High-Level System Architecture Diagram

```mermaid
flowchart TD
    subgraph BrowserClient["Client Browser (User Device)"]
        UI["React 18 SPA (ChefVideoPlayer & App.jsx)"]
        Cam["HTML5 MediaStream (navigator.mediaDevices.getUserMedia)"]
        VideoEl["HTML5 Video Element (Chef Recipe Stream)"]
        
        subgraph MediaPipeEngine["MediaPipe Tasks-Vision Engine (Client-Side)"]
            WASM["WebAssembly Runtime (Tasks Vision WASM)"]
            GPU["WebGL / WebGPU Delegate (float16 Model)"]
            Recognizer["GestureRecognizer.recognizeVideo()"]
        end
        
        Cam -->|Live 640x480 Video Frames| Recognizer
        Recognizer -->|Gestures & Confidence > 0.75| UI
        UI -->|Play/Pause, Seek +/-10s, Zoom 125%/100%| VideoEl
    end

    subgraph ExternalCDNs["External Cloud Asset Providers"]
        GoogleStorage["Google Cloud Storage CDN (Sample MP4s & Task Bundle)"]
        JSDelivr["JSDelivr CDN (WASM Binaries)"]
    end

    JSDelivr -.->|Download WASM Runtime| WASM
    GoogleStorage -.->|Download gesture_recognizer.task (float16)| GPU
    GoogleStorage -.->|Stream MP4 Video Data| VideoEl
```

---

## 4. Documentation Strategy & Prompt Adaptation

In compliance with **Rule 8 (Adapt to Project Type)**:
1. **Frontend Core & Client-Side Vision**: Deep dive into React component lifecycles, `useRef` frame loops, `requestAnimationFrame` synchronization, MediaPipe Vision Task graph execution, WebAssembly/GPU memory management, and browser hardware permissions (`getUserMedia`).
2. **Backend & Database Sections**: Sections requiring Express, Node servers, MongoDB schemas, or server-side auth are marked clearly as **'Not applicable for this project type'** with a rigorous technical justification. We also provide the exact architectural migration blueprint showing how a backend/database would be attached for production scaling (e.g., custom user bookmarks, cloud sync, analytics).
3. **AI Integration**: Explains the pre-trained Google MediaPipe gesture recognizer model (`gesture_recognizer.task`), float16 quantization, WASM runtime loading from JSDelivr CDN, confidence filtering (0.75 threshold), debouncing (1500ms cooldown), and why an on-device edge model was chosen over server-side LLMs or computer vision inference APIs.
4. **Interview Readiness**: Bridges the gap between frontend DOM manipulation, computer vision math (landmarks, coordinates, handedness, bounding boxes), and scalable distributed systems design.
