# Step 11: Engineering Gaps & Prioritized Improvements

This audit catalogs technical gaps, missing features, and production enhancements an engineering interviewer or tech lead would identify, ranked in order of architectural importance with concrete implementation plans.

---

## Prioritized Improvements Matrix

```mermaid
quadrantChart
    title Production Readiness vs Implementation Effort
    x-axis Low Effort --> High Effort
    y-axis Low Value --> High Value
    quadrant-1 Strategic Bets
    quadrant-2 Quick Wins
    quadrant-3 Low Priority
    quadrant-4 Complex Upgrades
    "Automated Testing (Vitest & Playwright)": [0.45, 0.95]
    "Service Worker Offline Caching (PWA)": [0.35, 0.90]
    "Strict Custom URL Validation": [0.15, 0.85]
    "Adaptive Frame Skipping (30 FPS)": [0.25, 0.80]
    "Web Audio Synthesizer Chimes": [0.20, 0.70]
    "Custom Gesture Training Engine": [0.85, 0.85]
    "Centralized Telemetry (Sentry)": [0.30, 0.65]
    "Video Volume Hand Tracking": [0.55, 0.60]
```

---

## 1. Automated Testing Suite (Rank 1: Critical)
- **Current State**: Zero unit tests, integration tests, or end-to-end browser tests.
- **Interviewer Concern**: "How can you refactor or upgrade dependencies without breaking video seeking boundaries or cooldown logic?"
- **Fix Suggestion**:
  1. Install Vitest and React Testing Library: `npm i -D vitest @testing-library/react jsdom`.
  2. Implement unit tests verifying seeking edge cases (`Math.min` duration and `Math.max` zero boundaries).
  3. Install Playwright: `npm i -D @playwright/test` using Chromium flags `--use-fake-device-for-media-stream` to simulate virtual webcam feeds in CI.

---

## 2. Progressive Web App & Offline Caching (Rank 2: High)
- **Current State**: Model files (`gesture_recognizer.task`) and WASM binaries are loaded dynamically from public CDNs. If a chef's kitchen Wi-Fi is spotty, the model may fail to initialize.
- **Interviewer Concern**: "What happens when an internet outage occurs in a basement kitchen?"
- **Fix Suggestion**:
  1. Install `vite-plugin-pwa`: `npm i -D vite-plugin-pwa`.
  2. Configure a Workbox service worker caching CDN requests to `storage.googleapis.com` and `cdn.jsdelivr.net`.
  3. Allow users to install Touchless Chef as an offline desktop/tablet application.

---

## 3. Strict Custom Video URL Validation & Protocol Filtering (Rank 3: High)
- **Current State**: `App.jsx:19` checks `customInput.trim()` before committing the URL.
- **Interviewer Concern**: "Can an attacker supply malformed URIs, local file schemes (`file://`), or protocol exploits?"
- **Fix Suggestion**:
  Replace basic string trimming with standard URL validation:
  ```javascript
  const isValidMediaUrl = (input) => {
    try {
      const url = new URL(input);
      const isHttp = ['http:', 'https:'].includes(url.protocol);
      const hasMediaExt = /\.(mp4|webm|ogg|m4v)(\?.*)?$/i.test(url.pathname);
      return isHttp && hasMediaExt;
    } catch {
      return false;
    }
  };
  ```

---

## 4. Adaptive Frame-Skipping & Battery Throttling (Rank 4: Medium)
- **Current State**: `predictLoop` runs on every single animation frame (60 FPS).
- **Interviewer Concern**: "Doesn't continuous 60 FPS GPU inference drain laptop batteries and cause thermal fan noise in hot kitchens?"
- **Fix Suggestion**:
  Execute inference on alternate frames (30 FPS), which halves GPU power consumption while preserving sub-35ms human reaction speeds:
  ```javascript
  let frameCount = 0;
  const predictLoop = () => {
    frameCount++;
    if (frameCount % 2 === 0 && GestureManager.recognizer) {
      // Execute inference every 2nd frame
      const results = GestureManager.recognizer.recognizeVideo(cam, Date.now());
      // Process gestures...
    }
    animId = requestAnimationFrame(predictLoop);
  };
  ```

---

## 5. Web Audio API Acoustic Feedback Chimes (Rank 5: Medium)
- **Current State**: Feedback is visual only (floating badges on screen).
- **Interviewer Concern**: "Chefs looking down at cutting boards can't see the visual HUD tag when they pause a recipe."
- **Fix Suggestion**:
  Synthesize subtle audio chimes using the native Web Audio API (zero external asset requests):
  ```javascript
  const playChime = (frequency = 440, type = 'sine') => {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(frequency, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.2);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.2);
  };
  ```

---

## 6. Centralized Telemetry & Error Tracking (Rank 6: Low)
- **Current State**: Errors are logged exclusively to the browser developer console via `console.error`.
- **Interviewer Concern**: "How do you detect broken browser versions or webcam driver faults in production?"
- **Fix Suggestion**:
  Integrate Sentry for React (`@sentry/react`) to capture uncaught promise rejections from `getUserMedia` and MediaPipe initialization.
