# Step 12: Technical Glossary & Architectural Terms

A comprehensive alphabetical reference guide defining technical terminology, protocols, machine learning concepts, and browser APIs utilized in Touchless Chef.

---

### A
- **Adapter Pattern**: A structural software design pattern that enables objects with incompatible interfaces to collaborate. Used in `gestureMap.js` to translate raw machine learning outputs to semantic player actions.
- **Autoprefixer**: A PostCSS plugin that parses CSS rules and adds vendor prefixes (such as `-webkit-`, `-moz-`) using values from Can I Use.

### B
- **BlazePalm**: Google's lightweight single-shot detector (SSD) neural network architecture optimized for mobile and edge devices to locate palms and hand bounding boxes in video frames.
- **Brotli**: A lossless data compression algorithm developed by Google that provides higher compression ratios than Gzip, used by modern CDNs to serve WebAssembly binaries.

### C
- **Content Delivery Network (CDN)**: A geographically distributed network of proxy servers that cache static assets (WASM binaries, model task files, video chunks) near end users to minimize latency.
- **Content Security Policy (CSP)**: An HTTP response header allowing site administrators to declare approved sources of content that browsers are permitted to load and execute.
- **Cooldown Hysteresis**: A time-delay buffer enforced between consecutive actions to prevent rapid oscillating state changes.

### D
- **Debounce**: A programming practice that delays the execution of a function until a certain amount of quiet time has elapsed since its last invocation.
- **Delegate (MediaPipe)**: The hardware execution backend (e.g. CPU, WebGL, WebGPU) assigned to calculate neural network matrix operations.

### E
- **Edge AI**: The deployment of artificial intelligence algorithms directly on local hardware devices (smartphones, laptops, IoT) rather than streaming data to centralized cloud servers.
- **ES Modules (ESM)**: The official standardized JavaScript module specification using `import` and `export` statements.

### F
- **FlatBuffer**: An efficient cross-platform serialization library created by Google, used as the `.task` file container format for MediaPipe models to allow zero-copy memory access.
- **float16 (FP16)**: Half-precision 16-bit floating-point format used to store neural network weights, cutting memory size in half compared to standard 32-bit float32 models.

### G
- **GestureRecognizer**: The high-level MediaPipe Vision Task API class that coordinates palm detection, 21-point landmark extraction, and pose classification.
- **getUserMedia**: A W3C Web API method on `navigator.mediaDevices` that prompts the user for permission to capture video and audio hardware streams.

### H
- **Hot Module Replacement (HMR)**: A development feature where modules are updated in the browser in real time without triggering a full page reload, preserving application state.
- **HTTP Range Requests**: Standardized HTTP headers (`Range: bytes=0-`) allowing browsers to request specific byte slices of large media files for smooth seeking and streaming.

### L
- **Landmarks (Hand)**: Twenty-one distinct three-dimensional anatomical points (joints and tips) estimated on the human hand by MediaPipe.
- **Lucide React**: An open-source, tree-shakeable SVG icon collection implemented as pure React components.

### M
- **MediaStream**: An interface representing a synchronized stream of media content containing one or more audio or video `MediaStreamTrack` objects.

### P
- **PostCSS**: A software tool that transforms CSS styles using JavaScript plugins (such as Tailwind CSS and Autoprefixer).

### Q
- **Quantization**: A model optimization technique that converts floating-point weights to lower bit-width representations (e.g., float32 to float16) to reduce file size and accelerate inference.

### R
- **requestAnimationFrame**: A native browser API that requests the window execute a specified callback before the next browser repaint cycle, typically running at 60Hz.

### S
- **Single Page Application (SPA)**: A web application that dynamically updates the current web page with new data from the client or server rather than loading entire new pages from scratch.

### T
- **Tailwind CSS**: A utility-first CSS framework providing low-level styling classes to build custom user interfaces directly in markup.
- **Throttle**: A technique that restricts the execution of a function to at most once per specified duration.

### U
- **useRef**: A built-in React hook that returns a mutable reference object whose `.current` property persists across component re-renders without triggering new renders.

### V
- **Vite**: A next-generation frontend build tool created by Evan You that serves code via native ES modules during development and bundles with Rollup for production.

### W
- **WebAssembly (WASM)**: A portable binary code format that executes in modern web browsers at near-native hardware speed, enabling complex C++ vision runtimes to run in JavaScript environments.
- **WebGL**: A JavaScript API for rendering interactive 2D and 3D graphics within any compatible web browser without plugins, used by MediaPipe to accelerate neural network operations on the GPU.
