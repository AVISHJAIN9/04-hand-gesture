# Step 4: API & Service Reference

## 1. Backend REST API Endpoints Specification

### Overview
> **Status: Not applicable for this project type.**  
> Touchless Chef is an **edge AI frontend-only single-page application**. All computer vision inference and video state manipulation occur directly on the client's device inside WebAssembly and WebGL execution contexts. No custom backend server (Express, Fastify, Spring, Django) or REST/GraphQL endpoints exist in this repository.

### Theoretical Backend Specification (If Scaled to Cloud Persistence)
If a backend were attached for user bookmarks, recipe synchronization, or telemetry, the following standard RESTful API contracts would be implemented:

```mermaid
sequenceDiagram
    autonumber
    actor Client as React Client
    participant Auth as Auth Middleware (JWT)
    participant Rate as Rate Limiter (Redis)
    participant Route as Recipe Controller
    participant DB as MongoDB Cluster

    Client->>Auth: POST /api/v1/recipes (Bearer Token)
    Auth->>Rate: Check Rate Limit (100 req/min)
    Rate->>Route: Forward Request
    Route->>DB: Recipe.create(req.body)
    DB-->>Route: Created Document
    Route-->>Client: 201 Created { id, title, videoUrl }
```

| Method | Hypothetical Path | Auth Required | Request Body | Success Code | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `GET` | `/api/v1/recipes` | Optional | None | `200 OK` | Retrieves list of curated cooking tutorials. |
| `POST` | `/api/v1/recipes` | Required (`Chef` role) | `{ title, url, duration }` | `201 Created` | Saves a custom recipe stream to cloud profile. |
| `POST` | `/api/v1/telemetry/gestures` | None | `{ gesture, confidence, latencyMs }` | `204 No Content` | Collects anonymous accuracy metrics. |

---

## 2. External CDN & Cloud APIs Called

### 1. Google Cloud Storage: MediaPipe Model Task Bundle
- **Endpoint URL**: `https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/1/gesture_recognizer.task`
- **Method**: `GET`
- **Purpose**: Fetches the 5.6MB float16 quantized neural network containing gesture recognition graph definitions and tensor weights.
- **Headers**:
  - Request: `Accept: */*`
  - Response: `Content-Type: application/octet-stream`, `Cache-Control: public, max-age=31536000`
- **Timeouts & Retries**: Handled by browser `fetch` engine. If network drops, `createFromOptions` throws an asynchronous rejection caught in `ChefVideoPlayer.jsx:46`.

### 2. JSDelivr CDN: MediaPipe Vision WASM Binaries
- **Base URL**: `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm`
- **Assets Fetched**:
  - `vision_wasm_internal.js` (JavaScript glue code)
  - `vision_wasm_internal.wasm` (Compiled C++ computer vision binary)
- **Method**: `GET`
- **Purpose**: Instantiates the client-side WebAssembly virtual machine that decodes raw image pixels into tensors.

### 3. Google Cloud Storage: Sample Video Media Streams
- **URLs**:
  - `https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4`
  - `https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4`
  - `https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4`
- **Method**: `GET` (Supports HTTP `Range: bytes=0-` headers)
- **Purpose**: Supplies MP4 video chunks to the HTML5 `<video>` element.
- **Response Headers**: `Content-Range: bytes 0-1048575/158008374`, `Content-Type: video/mp4`, `Status: 206 Partial Content`.

---

## 3. Client-Side Software Services & Module APIs

### 1. `GestureManager` Service API ([GestureManager.js](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureManager.js))
Singleton class orchestrating computer vision model loading and webcam streams.

#### `initialize(): Promise<void>`
- **Description**: Loads WASM filesets and compiles the float16 gesture recognizer model on the client's GPU.
- **Parameters**: None.
- **Returns**: `Promise<void>` (resolves when recognizer is ready).
- **Error Modes**: Rejects if CDN assets are unreachable or WebGL context cannot be created.

#### `startCamera(videoElement: HTMLVideoElement): Promise<boolean>`
- **Description**: Prompts user for camera permissions and binds the media stream to the supplied hidden video element.
- **Parameters**:
  - `videoElement` (`HTMLVideoElement`): Reference to hidden DOM video tag.
- **Returns**: `Promise<boolean>` (`true` if access granted; `false` if user denies permission).
- **Media Constraints**:
  ```javascript
  { video: { width: 640, height: 480, facingMode: "user" } }
  ```

#### `stop(): void`
- **Description**: Gracefully stops all active audio/video tracks in `this.stream`.
- **Parameters**: None.
- **Returns**: `void`.

---

### 2. `useGesture` Custom Hook API ([useGesture.js](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/hooks/useGesture.js))
Encapsulates the `requestAnimationFrame` detection loop into a reusable React hook.

#### `useGesture(videoElement, onGesture)`
- **Parameters**:
  - `videoElement` (`HTMLVideoElement`): Live camera video DOM element.
  - `onGesture` (`Function(categoryName: string)`): Callback invoked whenever a gesture is classified.
- **Returns**:
  ```javascript
  {
    detect: (recognizer, webcam) => Promise<void>,
    requestRef: MutableRefObject<number>
  }
  ```

---

### 3. MediaPipe `recognizeVideo` Result Shape
When `recognizeVideo(videoElement, timestamp)` executes synchronously, it returns an object adhering to the following schema:

```json
{
  "gestures": [
    [
      {
        "categoryName": "Open_Palm",
        "displayName": "",
        "score": 0.8842,
        "index": 1
      }
    ]
  ],
  "handedness": [
    [
      {
        "categoryName": "Right",
        "displayName": "",
        "score": 0.9812,
        "index": 0
      }
    ]
  ],
  "landmarks": [
    [
      { "x": 0.542, "y": 0.631, "z": -0.012 },
      { "x": 0.518, "y": 0.589, "z": -0.024 }
    ]
  ],
  "worldLandmarks": [
    [
      { "x": 0.042, "y": 0.121, "z": -0.015 }
    ]
  ]
}
```
