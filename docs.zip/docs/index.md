---
layout: home

hero:
  name: "Touchless Chef"
  text: "Interview-Ready Project Documentation"
  tagline: "Hands-Free Gesture-Controlled Video Player Powered by Google MediaPipe Edge Vision AI"
  actions:
    - theme: brand
      text: Project Overview & Trace
      link: /00a-project-analysis
    - theme: alt
      text: Say It Out Loud (Spoken Rehearsal)
      link: /14-say-it-out-loud
    - theme: alt
      text: 155 Interview Q&As
      link: /09-interview-qa

features:
  - icon: ✋
    title: Real-Time Edge AI Vision
    details: Pre-trained Google MediaPipe Vision Tasks running inside browser WebAssembly and WebGL shaders at 60 FPS with zero cloud costs.
    link: /features/f1-gesture-recognition-engine
  - icon: 🍲
    title: Hands-Free Kitchen Control
    details: Play, pause, skip (+/-10s), and zoom (125%) without touching screens or peripherals with wet, oily, or gloved hands.
    link: /features/f2-touchless-video-control
  - icon: ⏱️
    title: 1500ms Hysteresis Cooldown
    details: Engineered with React useRef to eliminate 60 FPS actuation flutter and duplicate triggering with zero component re-renders.
    link: /features/f5-gesture-debounce-engine
  - icon: 📐
    title: System Design Deep Dive
    details: 18 dedicated system design chapters analyzing capacity, latency budgets, edge computing, caching, and 100x scaling.
    link: /system-design/README
  - icon: 🎙️
    title: Say It Out Loud Rehearsal
    details: First-person spoken English scripts for every single feature, designed specifically for college internship and fresher interviews.
    link: /14-say-it-out-loud
  - icon: 📋
    title: 275-Item Master Checklist
    details: Comprehensive 7-part engineering audit across project foundation, architecture, frontend, AI, security, and DevOps.
    link: /13-master-checklist
---
