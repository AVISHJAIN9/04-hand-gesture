# Step 0: Full Project Analysis

## 0.1 What the Project Is

### Project Identity & Core Mission
**Touchless Chef** (`hand-gesture-cv`) is an edge AI computer vision single-page web application engineered to solve a pervasive problem in culinary arts, medical workshops, and laboratory kitchens: **hands-free media playback control**. When cooking or performing tactile work, users have hands covered in flour, oil, water, or sterile gloves. Interacting with touchscreens, keyboards, or remotes causes screen contamination, physical cross-contamination of food allergens/pathogens, and hardware damage.

Touchless Chef eliminates tactile contact by converting an ordinary user webcam into a real-time gesture controller using **Google MediaPipe Vision Tasks**. It executes an on-device machine learning pipeline entirely inside the browser's WebAssembly and WebGL execution contexts, ensuring zero-latency control, total user privacy (video frames never leave the device), and zero server compute overhead.

### Target User Personas
1. **Home & Professional Chefs**: Preparing complex recipes where steps must be rewound or paused while both hands are kneading dough or seasoning meat.
2. **Culinary Instructors & Students**: Demonstrating techniques on large kitchen monitors without stepping away from the prep station.
3. **Food Content Creators**: Recording reaction or tutorial videos while dynamically seeking video markers hands-free.
4. **Cleanroom & Healthcare Technicians**: Reviewing procedural instructional videos in sanitized environments where touching peripherals breaks sterility.

### Primary User Journeys
1. **Onboarding & Permission Flow**: User opens the web application $\rightarrow$ browser requests webcam access $\rightarrow$ user grants permission $\rightarrow$ MediaPipe WebAssembly runtime and float16 model task download from CDN $\rightarrow$ live tracking status turns green ("Touchless Control Active").
2. **Hands-Free Cooking Playback**: User plays recipe video $\rightarrow$ user needs to halt at a critical marinade step $\rightarrow$ user raises an **Open Palm** (`Open_Palm`) $\rightarrow$ video pauses immediately $\rightarrow$ floating HUD confirms "⏸️ Paused" $\rightarrow$ user inspects ingredients $\rightarrow$ raises **Open Palm** again to resume.
3. **Technique Zoom & Inspection Flow**: Chef needs to inspect the knife angle in the video $\rightarrow$ raises **Thumbs Up** (`Thumb_Up`) $\rightarrow$ video smoothly scales to 125% zoom $\rightarrow$ chef finishes observing $\rightarrow$ raises **Thumbs Down** (`Thumb_Down`) $\rightarrow$ video resets to 100% scale.
4. **Step Replay (Scrubbing) Flow**: Chef misses a seasoning quantity $\rightarrow$ flashes **Victory/Peace Sign** (`Victory`) $\rightarrow$ video scrubs back 10 seconds (`currentTime - 10`) $\rightarrow$ flashes **Pointing Up** (`Pointing_Up`) to jump forward 10 seconds.
5. **Custom Recipe Video Ingestion**: User pastes a custom direct MP4/WebM video URL into the dashboard form $\rightarrow$ clicks "Load Video" $\rightarrow$ player immediately mounts the custom stream without restarting the computer vision model.

### Screens & Routing
- **Route**: Single-Page Application (`/` root route managed by Vite in [index.html](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/index.html)).
- **Layout**: High-contrast, dark-mode culinary command dashboard featuring the primary video canvas, floating visual feedback badges, collapsible webcam mirror inset, quick recipe switcher pill buttons, custom URL input form, and gesture instruction cheat sheet.

---

## 0.2 Every Feature with Full Trace (F1 – F12)

### F1: Real-Time Hand Gesture Detection & Recognition Engine
- **User Action**: User places hand in front of camera.
- **Frontend Flow**: [ChefVideoPlayer.jsx:15-49](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L15-L49) mounts $\rightarrow$ calls `GestureManager.initialize()` ([GestureManager.js:9-24](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureManager.js#L9-L24)) $\rightarrow$ resolves WASM binaries and loads float16 model $\rightarrow$ calls `GestureManager.startCamera(hiddenCamRef.current)` ([GestureManager.js:26-37](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureManager.js#L26-L37)) $\rightarrow$ initiates recursive `requestAnimationFrame(predictLoop)` $\rightarrow$ runs `GestureManager.recognizer.recognizeVideo(video, timestamp)` at 60 FPS $\rightarrow$ filters predictions by confidence score (`score > 0.75`) $\rightarrow$ updates `activeGesture` state ([ChefVideoPlayer.jsx:32](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L32)).
- **External API / SDK**: `FilesetResolver.forVisionTasks()` downloads WASM runtime; `GestureRecognizer.createFromOptions()` fetches `gesture_recognizer.task`.
- **Backend / DB Flow**: Not applicable (edge AI running on browser GPU/WASM).
- **Failure Path**: Webcam denied $\rightarrow$ caught in [GestureManager.js:33-36](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureManager.js#L33-L36), returns `false`, UI remains in amber state ("Initializing MediaPipe Vision Model..."). Model CDN failure $\rightarrow$ caught in [ChefVideoPlayer.jsx:46-48](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L46-L48), error logged to console.

```mermaid
flowchart TD
    A["User mounts ChefVideoPlayer"] --> B["GestureManager.initialize()"]
    B --> C["Fetch WASM & float16 Model"]
    C --> D["GestureManager.startCamera()"]
    D --> E{"Camera Access Granted?"}
    E -->|No| F["Log Error & Amber Status UI"]
    E -->|Yes| G["predictLoop() on requestAnimationFrame"]
    G --> H["recognizeVideo(cam, timestamp)"]
    H --> I{"Confidence > 0.75?"}
    I -->|Yes| J["setActiveGesture(categoryName)"]
    I -->|No| K["setActiveGesture(null)"]
```

```mermaid
sequenceDiagram
    autonumber
    actor User
    participant Player as ChefVideoPlayer.jsx
    participant GM as GestureManager.js
    participant MP as MediaPipe WASM / GPU
    participant Video as Hidden Video Element

    User->>Player: Mounts Application
    Player->>GM: initialize()
    GM->>MP: Load WASM & Task Model
    MP-->>GM: Recognizer Ready
    Player->>GM: startCamera(hiddenCamRef)
    GM->>Video: stream = getUserMedia()
    GM-->>Player: hasAccess = true
    loop Every Animation Frame
        Player->>MP: recognizeVideo(video, Date.now())
        MP-->>Player: Gesture Results [Category, Score]
        alt Score > 0.75
            Player->>Player: setActiveGesture(name)
        else Score <= 0.75
            Player->>Player: setActiveGesture(null)
        end
    end
```

```mermaid
stateDiagram-v2
    [*] --> Uninitialized
    Uninitialized --> LoadingModel: initialize()
    LoadingModel --> CameraRequesting: Model Loaded
    CameraRequesting --> CameraDenied: Permission Blocked
    CameraRequesting --> TrackingActive: Permission Granted
    TrackingActive --> GestureDetected: Confidence > 0.75
    GestureDetected --> TrackingActive: Gesture Lost / Confidence <= 0.75
```

```mermaid
flowchart LR
    A["Failure: getUserMedia Denied"] --> B["Catch Block in GestureManager.js:33"]
    B --> C["hasAccess = false"]
    C --> D["cameraActive state stays false"]
    D --> E["UI displays Amber Initializing Banner"]
```

---

### F2: Touchless Video Playback Control (Play / Pause)
- **User Action**: User raises an open palm facing the webcam.
- **Frontend Flow**: Recognized gesture is `"Open_Palm"` with `score > 0.75` $\rightarrow$ debouncer checks `Date.now() - lastActionTime.current > 1500` ([ChefVideoPlayer.jsx:33](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L33)) $\rightarrow$ calls `executeCommand("Open_Palm")` ([ChefVideoPlayer.jsx:58-73](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L58-L73)) $\rightarrow$ checks `video.paused` $\rightarrow$ if paused, calls `video.play()`, sets `isPlaying(true)`, sets `feedback("▶️ Playing")`; if playing, calls `video.pause()`, sets `isPlaying(false)`, sets `feedback("⏸️ Paused")`.
- **Backend / DB Flow**: Not applicable.
- **Failure Path**: HTML5 video element unmounted or ref null $\rightarrow$ safely guarded by `if (!video) return` ([ChefVideoPlayer.jsx:60](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L60)). Browser autoplay policy blocks unmuted play $\rightarrow$ browser rejects promise, video controls retain native state.

```mermaid
flowchart TD
    A["Recognized 'Open_Palm'"] --> B{"Cooldown > 1500ms?"}
    B -->|No| C["Ignore Frame"]
    B -->|Yes| D["executeCommand('Open_Palm')"]
    D --> E{"video.paused?"}
    E -->|True| F["video.play() + setIsPlaying(true) + '▶️ Playing'"]
    E -->|False| G["video.pause() + setIsPlaying(false) + '⏸️ Paused'"]
```

```mermaid
sequenceDiagram
    autonumber
    actor Chef
    participant Player as ChefVideoPlayer.jsx
    participant Video as HTML5 Video Element
    participant HUD as Overlay Feedback

    Chef->>Player: Displays Open Palm Gesture
    Player->>Player: executeCommand("Open_Palm")
    alt Video is Paused
        Player->>Video: video.play()
        Player->>HUD: setFeedback("▶️ Playing")
    else Video is Playing
        Player->>Video: video.pause()
        Player->>HUD: setFeedback("⏸️ Paused")
    end
```

```mermaid
stateDiagram-v2
    [*] --> Paused
    Paused --> Playing: Open_Palm (executeCommand)
    Playing --> Paused: Open_Palm (executeCommand)
```

```mermaid
flowchart LR
    A["Video Ref Null or Destroyed"] --> B["Guard Clause: if (!video) return"]
    B --> C["Execution halted safely with zero crash"]
```

---

### F3: Precision Video Seeking (Skip Forward +10s / Skip Backward -10s)
- **User Action**: Pointing index finger up (`Pointing_Up`) to jump forward, or peace sign (`Victory`) to rewind.
- **Frontend Flow**: Gesture detected $\rightarrow$ cooldown validated ($>1500$ ms) $\rightarrow$ `executeCommand("Pointing_Up")`: `video.currentTime = Math.min(video.duration, video.currentTime + 10)` ([ChefVideoPlayer.jsx:74-77](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L74-L77)) $\rightarrow$ `setFeedback("⏩ Jumped Forward (+10s)")`. For `"Victory"`: `video.currentTime = Math.max(0, video.currentTime - 10)` ([ChefVideoPlayer.jsx:78-81](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L78-L81)) $\rightarrow$ `setFeedback("⏪ Jumped Backward (-10s)")`.
- **Boundary Handling**: Clamped between `0` and `video.duration` using `Math.max` and `Math.min` to avoid NaN or overflow errors.

```mermaid
flowchart TD
    A["Gesture Detected"] --> B{"Gesture Type"}
    B -->|Pointing_Up| C["video.currentTime = Math.min(duration, currentTime + 10)"]
    B -->|Victory| D["video.currentTime = Math.max(0, currentTime - 10)"]
    C --> E["Update HUD: +10s"]
    D --> F["Update HUD: -10s"]
```

```mermaid
sequenceDiagram
    autonumber
    actor Chef
    participant Player as ChefVideoPlayer.jsx
    participant Video as HTML5 Video Element
    Chef->>Player: Flash Pointing_Up
    Player->>Video: currentTime += 10
    Chef->>Player: Flash Victory
    Player->>Video: currentTime -= 10
```

---

### F4: Interactive Video Frame Zoom & Inspection (Zoom In 125% / Reset 100%)
- **User Action**: Thumbs Up (`Thumb_Up`) to magnify video, Thumbs Down (`Thumb_Down`) to reset.
- **Frontend Flow**: `executeCommand("Thumb_Up")` sets `video.style.transform = "scale(1.25)"` and `video.style.transition = "transform 0.3s ease"` ([ChefVideoPlayer.jsx:82-86](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L82-L86)) $\rightarrow$ `setFeedback("🔍 Zoomed In (125%)")`. `executeCommand("Thumb_Down")` sets `video.style.transform = "scale(1)"` ([ChefVideoPlayer.jsx:87-91](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L87-L91)) $\rightarrow$ `setFeedback("🔎 Zoom Reset (100%)")`.
- **CSS Parent Containment**: Parent container `div` uses `overflow-hidden` ([ChefVideoPlayer.jsx:100](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L100)), ensuring 125% magnification expands within bounds without disrupting UI layout.

```mermaid
stateDiagram-v2
    [*] --> NormalScale: 100% (scale 1)
    NormalScale --> ZoomedIn: Thumb_Up (scale 1.25)
    ZoomedIn --> NormalScale: Thumb_Down (scale 1.0)
```

---

### F5: Dual Action Debounce & Cooldown Engine
- **Purpose**: Prevent consecutive frames (running at 60 FPS) from firing multiple toggle commands for a single continuous hand gesture.
- **Frontend Flow**: [ChefVideoPlayer.jsx:8, 33-36](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L8-L36) stores `lastActionTime = useRef(0)`. In `predictLoop`, command execution requires `Date.now() - lastActionTime.current > 1500`. Once executed, `lastActionTime.current = Date.now()`.
- **Benefit**: Re-renders do NOT reset the timer because `useRef` maintains instance identity across React lifecycle cycles.

---

### F6: Real-Time Visual Feedback & Live Gesture HUD Overlay
- **Frontend Flow**: Renders two floating status badges over the video:
  1. Live Detected Gesture Tag ([ChefVideoPlayer.jsx:119-123](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L119-L123)): Displays `Detected: {activeGesture.replace("_", " ")}` in upper right with pulsing emerald animation.
  2. Floating Feedback Overlay ([ChefVideoPlayer.jsx:111-116](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L111-L116)): Displays last action taken (`"▶️ Playing"`, `"⏸️ Paused"`, `"⏩ Jumped Forward (+10s)"`, etc.) in upper left with backdrop blur.

---

### F7: Inset Mirror Webcam Monitor & Toggle
- **Frontend Flow**: A hidden `<video>` element ([ChefVideoPlayer.jsx:126-137](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L126-L137)) receives the live `MediaStream` for MediaPipe processing. When the user clicks "Show Camera Inset", `showPreview` state toggles ([ChefVideoPlayer.jsx:151-156](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L151-L156)). The inset renders with CSS `-scale-x-100` so hand movements are mirrored naturally.

---

### F8: Interactive Recipe Video Switcher
- **Frontend Flow**: [App.jsx:11-15, 62-76](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/App.jsx#L11-L76) maintains `sampleVideos` array (Nature Demo, Kitchen Recipe, Tech Showcase). Clicking any pill button updates `videoUrl` state, passing the new source to `<ChefVideoPlayer videoSrc={videoUrl} />`. The video immediately updates without resetting the webcam stream or computer vision recognizer.

---

### F9: Custom Direct Video Stream / URL Loader
- **Frontend Flow**: [App.jsx:9, 17-23, 78-93](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/App.jsx#L9-L93) renders a form with an `<input type="url">`. On submission, `handleCustomSubmit` checks `customInput.trim()`, updates `videoUrl`, and clears the input.

---

### F10: Camera Permission & Hardware Lifecycle Management
- **Frontend Flow**: [GestureManager.js:26-43](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureManager.js#L26-L43) calls `navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480, facingMode: "user" } })`. On component unmount ([ChefVideoPlayer.jsx:54](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L54)), `GestureManager.stop()` calls `track.stop()` on every media track, ensuring the webcam hardware light turns off and memory is reclaimed.

---

### F11: Gesture Command Mapping Abstraction
- **Code Reference**: [src/utils/gestureMap.js](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/utils/gestureMap.js), [src/services/GestureService.js](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureService.js), [src/components/Gesture/GestureCore.js](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/Gesture/GestureCore.js).
- **Purpose**: Decouples MediaPipe raw string outputs (`OPEN_PALM`, `POINTING_UP`, `VICTORY`, `THUMB_UP`, `THUMB_DOWN`) into semantic actions (`TogglePlay`, `SeekForward`, `NextVideo`, `ZoomIn`, `ZoomOut`), allowing future gesture customization.

---

### F12: Dark-Themed Responsive Culinary UI Layout
- **Code Reference**: [App.jsx:26-132](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/App.jsx#L26-L132), [src/index.css](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/index.css).
- **Design System**: Emerald accent palette (`#10b981`), pure black canvas (`#030712`), zinc borders (`#27272a`), flexbox/grid layout optimized for tablet mounts, kitchen prep stands, and desktop displays.

---

## 0.3 Every API

### Backend Endpoints Table
| Method | Path | Auth Required | Controller | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| *N/A* | *N/A* | *N/A* | *N/A* | **Not applicable for this project type** (Pure client-side single page app; no backend API endpoints exist). |

### External APIs & SDKs Called
| Provider / SDK | Purpose | Where in Code | Asset / Endpoint URL |
| :--- | :--- | :--- | :--- |
| **MediaPipe Tasks Vision WASM** | WebAssembly binary loader for on-device inference | [GestureManager.js:10-12](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureManager.js#L10-L12) | `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm` |
| **Google Cloud Storage (Model Asset)** | Pre-trained gesture recognizer float16 task bundle | [GestureManager.js:16](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureManager.js#L16) | `https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/1/gesture_recognizer.task` |
| **Google Cloud Storage (Media CDN)** | Sample video streams for cooking & demo playback | [App.jsx:12-14](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/App.jsx#L12-L14) | `https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/*.mp4` |
| **HTML5 MediaDevices Web API** | Hardware webcam stream capture | [GestureManager.js:28-30](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureManager.js#L28-L30) | `navigator.mediaDevices.getUserMedia()` |

### API Keys and Secrets Table
| Variable Name | Service | Purpose | Where Read in Code | Where to Obtain |
| :--- | :--- | :--- | :--- | :--- |
| *None* | *Public CDNs* | Public open-access model assets and WASM runtimes; no private secrets required | *Zero env variables needed* | Model and WASM hosted publicly by Google and JSDelivr |

---

## 0.4 Every Hook, Helper, and Shared Piece

### React Hooks
| Hook | Type | Purpose | File & Location |
| :--- | :--- | :--- | :--- |
| `useState` | Built-in | Manages `videoUrl`, `customInput` | [App.jsx:6, 9](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/App.jsx#L6-L9) |
| `useState` | Built-in | Manages `activeGesture`, `cameraActive`, `showPreview`, `isPlaying`, `feedback` | [ChefVideoPlayer.jsx:9-13](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L9-L13) |
| `useRef` | Built-in | Holds DOM references (`videoRef`, `hiddenCamRef`) and timestamp tracker (`lastActionTime`) | [ChefVideoPlayer.jsx:6-8](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L6-L8) |
| `useEffect` | Built-in | Initializes MediaPipe recognizer, starts camera, binds `requestAnimationFrame` loop, handles cleanup | [ChefVideoPlayer.jsx:15-56](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L15-L56) |
| `useGesture` | Custom | Modular gesture hook encapsulating `recognizeVideo` detection loop | [src/hooks/useGesture.js:4-18](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/hooks/useGesture.js#L4-L18) |

### Helpers & Shared Modules
- `GestureManager` ([src/services/GestureManager.js](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureManager.js)): Singleton service managing model lifecycle and camera stream.
- `GestureService` ([src/services/GestureService.js](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/services/GestureService.js)): Alternate initializer for `useGesture` hook integration.
- `GESTURE_COMMANDS` ([src/utils/gestureMap.js](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/utils/gestureMap.js)): Semantic dictionary mapping gestures to video actions.

---

## 0.5 Every Connection

1. **Frontend to Hardware (Camera)**: Secured via standard `navigator.mediaDevices.getUserMedia()` over HTTPS or `localhost`.
2. **Frontend to Edge AI Model**: `FilesetResolver` and `GestureRecognizer.createFromOptions()` initiate HTTP GET requests to fetch WASM bytecode and the 5.6MB float16 `.task` binary. Once downloaded, the binary is compiled into the WebAssembly runtime and cached in memory.
3. **Frontend to Video CDN**: Standard HTTP Range requests to Google Cloud Storage bucket (`gtv-videos-bucket`) for streaming media playback.
4. **Backend / Database / Auth Connections**: Not applicable for this project type.

---

## 0.6 Everything Else Built into the Application

- **Form Validation**: Direct URL check with `.trim()` verification before state commitment ([App.jsx:19](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/App.jsx#L19)).
- **UI Notifications**: Floating animated badges with backdrop blur and Lucide icons.
- **Hardware Teardown**: Strict track termination `track.stop()` preventing battery drain and camera hijacking.
- **Responsive Theme**: Emerald-on-black dark UI with CSS flexbox wrapping for mobile, tablet, and widescreen monitors.

---

## 0.7 Connection Map

```mermaid
graph TD
    subgraph ClientDevice["Client Hardware & Browser"]
        CameraHardware["Webcam Hardware (640x480)"]
        BrowserNav["navigator.mediaDevices"]
        HiddenCam["Hidden HTML5 Video Element"]
        MainVideo["Main HTML5 Video Player"]
        
        subgraph ReactApp["React 18 Application Layer"]
            AppComp["App.jsx (State, Recipes, URL Input)"]
            PlayerComp["ChefVideoPlayer.jsx"]
            HUD["HUD Overlay & Feedback Badges"]
            CamInset["Collapsible Mirrored Cam Inset"]
        end
        
        subgraph AIServiceLayer["In-Memory Vision Services"]
            GM["GestureManager Singleton"]
            WASM["MediaPipe WASM Engine"]
            GPU["WebGL GPU Inference Pipeline"]
        end
    end

    subgraph CloudCDNs["Global Cloud Delivery Networks"]
        JSDelivr["JSDelivr CDN (WASM Assets)"]
        GCSModel["Google Cloud Storage (gesture_recognizer.task)"]
        GCSMedia["Google Cloud Storage (Sample MP4 Streams)"]
    end

    CameraHardware --> BrowserNav
    BrowserNav --> GM
    GM --> HiddenCam
    
    JSDelivr -.->|Download WASM| WASM
    GCSModel -.->|Download float16 weights| GPU
    
    HiddenCam -->|Raw Frame Stream| GPU
    GPU -->|Classified Gesture & Score| PlayerComp
    
    AppComp --> PlayerComp
    PlayerComp --> MainVideo
    PlayerComp --> HUD
    PlayerComp --> CamInset
    
    GCSMedia -.->|HTTP Range Video Data| MainVideo
```

---

## 0.8 Final Inventory Counts

| Metric Category | Count | Verification Code / Path |
| :--- | :--- | :--- |
| **Total Pages / Screens** | **1** | Single-page application root in [index.html](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/index.html) and [src/App.jsx](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/App.jsx) |
| **Total Components** | **2** | `App.jsx`, `ChefVideoPlayer.jsx` (+ 1 re-export module `GestureCore.js`) |
| **Total Custom Hooks** | **1** | `useGesture.js` in [src/hooks/useGesture.js](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/hooks/useGesture.js) |
| **Total Features Documented** | **12** | Features F1 through F12 |
| **Backend Endpoints** | **0** | *Not applicable for this project type* |
| **Database Models** | **0** | *Not applicable for this project type* |
| **Backend Middleware** | **0** | *Not applicable for this project type* |
| **External APIs & CDNs** | **3** | MediaPipe WASM CDN, GCS Task Model Bucket, GCS Sample Video Bucket |
| **Environment Variables** | **0** | Zero configuration required; client-side execution |
| **Total NPM Dependencies** | **9** | 4 `dependencies` + 5 `devDependencies` in [package.json](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/package.json) |

*All subsequent documentation sections remain strictly synchronized with these final counts.*
