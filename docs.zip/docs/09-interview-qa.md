# Step 10: Master Interview Preparation Guide (155 Q&As)

This document contains **155 comprehensive, project-specific interview questions and answers** designed to prepare the developer for any technical interview from college internships and fresher roles up to senior full-stack positions.

---

## Pillar 1: High-Priority Signature Answers

### 1. "Walk Me Through Your Project" (The 3-Minute Answer)
> "Touchless Chef is a client-side computer vision application I developed to solve a real-world tactile problem in kitchens, medical workshops, and classrooms: controlling recipe video playback without touching screens with messy, wet, or gloved hands.
>
> On the frontend, I built a Single Page Application using React 18, Vite, and Tailwind CSS. The core intelligence runs on Google MediaPipe's Vision Tasks, which downloads a float16 quantized neural network model and executes it directly inside the browser using WebAssembly and WebGL shaders on the user's graphics card.
>
> When the user launches the app, my `GestureManager` singleton requests webcam permissions using the HTML5 `getUserMedia` API, constraining the feed to 640-by-480 resolution. A continuous `requestAnimationFrame` loop passes frames into `recognizeVideo`, extracting 21 3D hand landmarks and classifying poses into five control commands:
> - **Open Palm** toggles between play and pause.
> - **Pointing Up** skips forward 10 seconds.
> - **Victory sign** skips backward 10 seconds.
> - **Thumbs Up** zooms the video into 125% for close inspection of knife techniques.
> - **Thumbs Down** resets zoom to 100%.
>
> One of my major engineering challenges was handling high-frequency execution: because the camera runs at 60 FPS, holding an open palm for half a second would trigger 30 rapid play/pause toggles. I engineered a two-stage guardrail: first, a confidence threshold filtering out any predictions below 75%; second, an action cooldown engine using React's `useRef` that enforces a 1500ms timestamp hysteresis without triggering component re-renders.
>
> I chose client-side edge inference over a cloud API backend because it eliminated cloud server bills entirely, cut response latency from 300ms down to 15ms, and ensures complete user privacy since video frames never leave client memory.
>
> Overall, the project demonstrates how modern browser APIs, WebAssembly, and quantized machine learning can create responsive, accessible user experiences."

---

### 2. The 60-Second Pitch
> "I built Touchless Chef, a hands-free recipe video player powered by on-device computer vision. In cooking and laboratory environments, touching keyboards or screens with wet, floury, or gloved hands creates cross-contamination and damages expensive hardware. Using React 18 and Google MediaPipe Vision Tasks, Touchless Chef tracks natural hand gestures like an Open Palm to play and pause, or a Thumbs Up to zoom into cooking techniques. Because the AI model runs locally in the browser through WebAssembly and WebGL, video frames are processed at 60 FPS with zero latency, zero cloud inference costs, and total privacy for the user."

---

### 3. The Hardest Function in the Project: Line-by-Line Breakdown
The most complex function is the **`predictLoop`** inside [ChefVideoPlayer.jsx:23-44](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L23-L44):

```javascript
23: const predictLoop = () => {
24:   if (GestureManager.recognizer && hiddenCamRef.current?.readyState === 4) {
25:     const results = GestureManager.recognizer.recognizeVideo(hiddenCamRef.current, Date.now());
26:     
27:     if (results.gestures && results.gestures.length > 0) {
28:       const gesture = results.gestures[0][0].categoryName;
29:       const score = results.gestures[0][0].score;
30:       
31:       if (score > 0.75) {
32:         setActiveGesture(gesture);
33:         if (Date.now() - lastActionTime.current > 1500) {
34:           executeCommand(gesture);
35:           lastActionTime.current = Date.now();
36:         }
37:       }
38:     } else {
39:       setActiveGesture(null);
40:     }
41:   }
42:   animId = requestAnimationFrame(predictLoop);
43: };
```

- **Line 24**: Validates that both the MediaPipe WebAssembly recognizer is compiled and the hidden webcam video element has reached `readyState === 4` (`HAVE_ENOUGH_DATA`). Without this check, calling `recognizeVideo` on an unbuffered frame throws DOM exceptions.
- **Line 25**: Synchronously invokes the neural network graph passing the video element and the current millisecond timestamp (`Date.now()`), required by MediaPipe's `"VIDEO"` running mode for temporal landmark tracking.
- **Lines 27-29**: Traverses the result matrix. `results.gestures[0][0]` accesses the primary candidate classification of the first detected hand, extracting the `categoryName` string and floating-point `score`.
- **Line 31**: Applies the statistical confidence guardrail (`score > 0.75`), discarding ambiguous poses or background movements.
- **Line 32**: Updates the visual HUD badge via React state.
- **Lines 33-36**: Evaluates the action hysteresis buffer. If 1500ms have elapsed since `lastActionTime.current`, it dispatches `executeCommand` to mutate the HTML5 video element and updates the timestamp without causing React re-renders.
- **Line 42**: Recursively schedules the next frame on the browser's vertical refresh cycle via `requestAnimationFrame`.

---

### 4. Bugs Faced and How They Were Solved
1. **The JSX in `.js` Build Crash**: The original imported file was named `ChefVideoPlayer.js`. Vite's esbuild parser rejects JSX syntax inside `.js` files by default. I resolved this by renaming to `.jsx` and establishing a clean re-export bridge in `GestureCore.js`.
2. **The "Rapid Stutter" Jitter Bug**: Early tests showed an open palm triggering 30 play/pause toggles per second. I fixed this by implementing the `useRef` timestamp hysteresis cooldown.
3. **Camera Hardware Lock on Unmount**: When switching routes or refreshing, the webcam indicator LED remained illuminated. I fixed this by implementing `GestureManager.stop()` in the `useEffect` cleanup hook to explicitly iterate and stop all media stream tracks.

---

### 5. "What Would You Change If You Rebuilt It?"
1. **Adaptive Frame Skipping**: Run inference every 2nd frame (30 FPS) instead of 60 FPS, reducing client GPU power consumption by 50%.
2. **Audio Chime Feedback**: Add Web Audio API synthesized chimes to acknowledge gesture actuation so cooks don't have to look at the screen.
3. **Offline Progressive Web App (PWA)**: Register a Service Worker with CacheStorage to cache the model bundle and WASM runtime, making the player 100% functional without an active internet connection.

---

## Group 1: Project Overview (Q1 – Q15)

#### Q1: What is the main problem Touchless Chef solves?
It eliminates physical contact with computer screens, tablets, and peripherals in messy environments like kitchens and medical workshops, preventing food pathogen cross-contamination and screen damage.

#### Q2: Who are the target users?
Home cooks, professional culinary students, workshop instructors, and laboratory technicians who review video instructions with contaminated or gloved hands.

#### Q3: Is there any backend server in this project?
No. It is a client-side single page application. All computer vision inference and playback manipulation happen locally on the user's device.

#### Q4: How is AI integrated into the project?
Through Google MediaPipe Vision Tasks (`@mediapipe/tasks-vision`), which runs a pre-trained gesture recognition neural network using WebAssembly and WebGL shaders in the browser.

#### Q5: Was a custom machine learning model trained for this project?
No. It uses Google's official pre-trained, float16 quantized `gesture_recognizer.task` model bundle.

#### Q6: What hand gestures are currently supported?
Open Palm (Play/Pause), Pointing Up (+10s Skip), Victory/Peace (-10s Rewind), Thumbs Up (Zoom 125%), and Thumbs Down (Zoom Reset 100%).

#### Q7: What external services or CDNs does the app depend on at runtime?
Google Cloud Storage (for model task bundle and sample videos) and JSDelivr CDN (for MediaPipe WebAssembly binaries).

#### Q8: Does the app require user registration or login?
No. It is designed as a frictionless, privacy-first utility tool with zero authentication requirements.

#### Q9: What happens to user camera video frames?
They are processed in volatile GPU memory and discarded immediately after inference. Frames are never recorded, saved to disk, or transmitted over any network.

#### Q10: What dependencies are installed in `package.json`?
`@mediapipe/tasks-vision`, `lucide-react`, `react`, `react-dom`, `@vitejs/plugin-react`, `autoprefixer`, `postcss`, `tailwindcss`, and `vite`.

#### Q11: How do you start the project locally?
Run `npm run dev` or double-click `start.bat`, then open `http://localhost:5173`.

#### Q12: Why are batch files (`install.bat`, `start.bat`) included?
To provide one-click convenience for non-technical users and chefs on Windows kitchen PCs without requiring terminal commands.

#### Q13: What license is the project under?
The ISC License.

#### Q14: What browser permissions are needed?
Webcam video access via `navigator.mediaDevices.getUserMedia`.

#### Q15: Does the application work on mobile devices?
Yes, any mobile browser supporting WebRTC `getUserMedia`, WebAssembly, and WebGL (e.g. Chrome for Android, Safari for iOS).

---

## Group 2: Architecture & System Design (Q16 – Q30)

#### Q16: How is the codebase structured?
It follows a feature-modular architecture: `components/` for React presentation, `services/` for singleton hardware/vision managers, `hooks/` for custom React logic, and `utils/` for static mappings.

#### Q17: Why did you use a Singleton pattern for `GestureManager`?
To guarantee that only one instance of the MediaPipe model and active camera stream exists in browser memory, preventing duplicate camera sessions.

#### Q18: What is the benefit of the `gestureMap.js` abstraction?
It decouples machine learning output labels from application command names, adhering to the Dependency Inversion Principle.

#### Q19: How would you scale this application to 100,000 concurrent users?
Because compute is decentralized to client devices, scaling requires no server compute scaling. We would only need a multi-region CDN (like Cloudflare) with HTTP Live Streaming (HLS) for video delivery.

#### Q20: What are the first three bottlenecks at scale?
Video CDN egress bandwidth costs, CDN cold-start rate limits on model downloads, and client CPU throttling on budget hardware.

#### Q21: What architecture pattern does the frontend follow?
Component-based presentation with unidirectional data flow and ref-based mutable DOM controllers.

#### Q22: Why not use a micro-frontend architecture?
Micro-frontends introduce unnecessary routing, iframe, and bundling complexity for a self-contained single-page application.

#### Q23: How does the component communicate with the video player?
Via standard React props (`videoSrc`) and native HTML5 DOM element references accessed via `videoRef.current`.

#### Q24: What design pattern is used in `useGesture.js`?
The Custom Hook Pattern, encapsulating browser animation frame loops and gesture callbacks into a reusable functional unit.

#### Q25: Why is `GestureCore.js` kept in `src/components/Gesture/`?
As a re-export bridge module ensuring backward compatibility for legacy imports after refactoring.

#### Q26: How would you introduce offline capabilities?
By adding a Service Worker that intercepts GET requests to JSDelivr and Google Cloud Storage, caching the WASM and `.task` binaries in CacheStorage.

#### Q27: How would you store user playlists if a database were added?
Using MongoDB with Mongoose, storing user accounts with embedded arrays of recipe bookmarks and timestamp notes.

#### Q28: How does state flow between `App.jsx` and `ChefVideoPlayer.jsx`?
`App.jsx` manages global recipe URL state and passes it downward as the `videoSrc` prop. Player internal states (`activeGesture`, `feedback`, `isPlaying`) are encapsulated inside `ChefVideoPlayer.jsx`.

#### Q29: What happens when the video URL changes?
The HTML5 `<video>` element updates its `src` attribute and buffers the new media stream, while the MediaPipe tracking loop remains active without reloading.

#### Q30: How is state shared between the camera inset and main player?
Both share the same parent component scope (`ChefVideoPlayer.jsx`), toggled via the `showPreview` boolean state.

---

## Group 3: Computer Vision & Edge AI (Q31 – Q50)

#### Q31: How does MediaPipe detect hands in video frames?
It uses a two-stage pipeline: first, the BlazePalm detector identifies the palm bounding box; second, the Hand Landmark Model predicts 21 3D coordinates.

#### Q32: What is the difference between `runningMode: "IMAGE"` and `"VIDEO"`?
`"IMAGE"` processes frames independently as static images. `"VIDEO"` mode tracks landmarks continuously over time, applying temporal filtering to eliminate coordinate jitter.

#### Q33: Why did you set `delegate: "GPU"`?
To instruct MediaPipe to compile neural network operations into WebGL shaders, running inference on the GPU rather than blocking the CPU main thread.

#### Q34: What is float16 quantization?
It converts 32-bit floating-point weights into 16-bit half-precision numbers, cutting model file size in half with virtually no loss in classification accuracy.

#### Q35: What confidence threshold is enforced in the code?
0.75 (`score > 0.75`). Any prediction with lower probability is discarded.

#### Q36: What are the 21 hand landmarks?
Coordinates for the wrist, four thumb joints, and four joints for each of the index, middle, ring, and pinky fingers.

#### Q37: How does MediaPipe distinguish an Open Palm from a Fist?
By comparing Euclidean distances between finger tip landmarks and wrist landmark 0 against palm joint baselines.

#### Q38: What coordinate space does `recognizeVideo` return?
Normalized coordinates from $0.0$ to $1.0$ across image width (X) and height (Y), with relative depth (Z) scaled to wrist reference.

#### Q39: What is `FilesetResolver`?
A MediaPipe utility that resolves and fetches the matching WebAssembly bytecode and metadata required by Vision Tasks.

#### Q40: What happens if the user presents two hands?
`numHands: 1` is configured in `GestureManager.js:20`, so the model only tracks the single most prominent hand in view.

#### Q41: Can MediaPipe detect gestures in poor kitchen lighting?
Yes, but extreme underexposure or lens glare reduces landmark confidence below the 0.75 threshold, safely suppressing false triggers.

#### Q42: Why not run the model inside a Web Worker?
While running in a Web Worker offloads CPU cycles, transferring high-resolution `VideoFrame` or `ImageBitmap` objects across worker boundaries introduces serialization overhead. With GPU delegation, main thread overhead is already minimal.

#### Q43: How much GPU memory does the model consume?
Approximately 25 to 45 MB of VRAM for texture buffers and shader weights.

#### Q44: What is the inference time per frame on a modern laptop?
Between 10 and 18 milliseconds, comfortably fitting inside the 16.6ms window of a 60 FPS refresh cycle.

#### Q45: What happens if the browser lacks WebGL support?
MediaPipe falls back to CPU WebAssembly execution, which increases inference latency to 40–65ms.

#### Q46: Can the model track hand rotation?
Yes, BlazePalm calculates rotation vectors based on wrist-to-middle-finger angles, normalizing rotation before landmark estimation.

#### Q47: Does MediaPipe require an active internet connection after loading?
No. Once the WASM runtime and `.task` bundle are cached in memory or disk cache, inference is 100% offline.

#### Q48: How would you train a new custom gesture?
Using Google MediaPipe Model Maker in Python, feeding labeled image folders to generate a new `.task` bundle.

#### Q49: What is `minHandDetectionConfidence: 0.7`?
The minimum statistical threshold required for the BlazePalm model to confirm a hand exists before launching landmark tracking.

#### Q50: What is `minTrackingConfidence: 0.7`?
The threshold used to maintain tracking continuity across consecutive frames without re-invoking the heavier palm detection graph.

---

## Group 4: Frontend Engineering & React (Q51 – Q75)

#### Q51: Why did you use `useRef` for `lastActionTime` instead of `useState`?
Because updating `lastActionTime` occurs inside a 60 FPS animation loop. Using `useState` would trigger 60 React component re-renders per second, causing massive frame drops.

#### Q52: What is the role of `hiddenCamRef`?
It references a hidden `<video>` element in the DOM that streams raw camera frames for MediaPipe without displaying them on screen.

#### Q53: What does `readyState === 4` mean on a video element?
It corresponds to `HTMLMediaElement.HAVE_ENOUGH_DATA`, confirming the video has buffered sufficient frames to execute inference safely.

#### Q54: How does `requestAnimationFrame` differ from `setInterval`?
`requestAnimationFrame` pauses automatically when the user switches tabs, saving CPU and battery, and synchronizes callbacks with the monitor's vertical blanking interval.

#### Q55: How is hardware cleanup handled when the component unmounts?
The `useEffect` in `ChefVideoPlayer.jsx` returns a cleanup function that cancels the active animation frame (`cancelAnimationFrame`) and calls `GestureManager.stop()`.

#### Q56: Why does the camera inset use `-scale-x-100`?
To mirror the video horizontally (`scaleX(-1)`), making hand movements feel natural like looking into a mirror.

#### Q57: What does `pointer-events-none` do on the HUD overlays?
It allows mouse clicks to pass straight through the overlay elements, ensuring the chef can click native video controls underneath.

#### Q58: How is the zoom feature implemented?
By mutating `video.style.transform = "scale(1.25)"` and `transition = "transform 0.3s ease"` directly on the video DOM element.

#### Q59: Why is `overflow-hidden` used on the player container?
To crop the magnified video frame at 125% zoom, preventing it from overflowing outside the player boundaries.

#### Q60: How does `App.jsx` prevent page reloads on custom URL submission?
By invoking `e.preventDefault()` inside `handleCustomSubmit`.

#### Q61: What is the purpose of `React.StrictMode` in `main.jsx`?
It highlights potential side effects by double-invoking lifecycles in development mode.

#### Q62: What problem occurred with `ChefVideoPlayer.js` in Vite?
Vite uses esbuild, which strictly requires `.jsx` extensions to parse JSX markup. Renaming to `.jsx` resolved the build error.

#### Q63: How are CSS classes generated in this project?
PostCSS scans source files at build time, and Tailwind purges unused rules, emitting a tiny production stylesheet.

#### Q64: What is `backdrop-blur-md` used for?
To apply real-time frosted glassmorphism behind the floating HUD badges, ensuring high contrast against any video background.

#### Q65: Why is `playsInline` added to the video elements?
To prevent mobile iOS Safari from forcing video streams into full-screen native players, keeping our custom HUD overlays visible.

#### Q66: What is a controlled component in React, and where is it used?
The custom URL input in `App.jsx`, where its value is bound to `customInput` state and updated via `onChange`.

#### Q67: How does the application handle video seeking boundaries?
It clamps timestamps using `Math.max(0, ...)` to prevent negative time, and `Math.min(video.duration, ...)` to prevent seeking past the video end.

#### Q68: Why use Lucide React icons over FontAwesome?
Lucide icons are modern, tree-shakeable SVG components that compile into minimal JavaScript with zero external font asset requests.

#### Q69: What is the difference between `useRef` and a regular JavaScript variable?
A regular variable declared inside a component function resets on every re-render. A `useRef` persists its object reference across the component's entire lifecycle.

#### Q70: What is the purpose of the `feedback` state?
It provides textual notifications on the player HUD (e.g. "▶️ Playing", "🔍 Zoomed In") confirming that a gesture was processed.

#### Q71: Why is `autoPlay` and `muted` required on the camera preview element?
Browsers block video autoplay unless the media element is explicitly muted or has no audio tracks.

#### Q72: How are responsive grid columns defined in the cheat sheet?
Using Tailwind utilities: `grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3`.

#### Q73: What is the purpose of the `cameraActive` state?
It drives the visual status indicator in the control bar, showing a green pulsing dot when the camera is active.

#### Q74: Why is `videoRef` initialized to `null`?
In React, DOM refs are `null` during initial evaluation and only populate once the JSX node mounts in the actual browser DOM.

#### Q75: How does the video player handle null checks?
The command executor includes a guard clause `if (!video) return;` before calling any media methods.

---

## Group 5: Core JavaScript, Media & Browser APIs (Q76 – Q100)

#### Q76: What is the JavaScript Event Loop?
A single-threaded runtime model that executes synchronous code on the Call Stack and continuously processes asynchronous callbacks from the Microtask (Promises) and Macrotask (Timers, I/O) queues.

#### Q77: Where does `requestAnimationFrame` fit in the event loop?
It executes immediately before the browser's style recalculation, layout, and paint phases, ensuring smooth visual synchronization.

#### Q78: What is the difference between `Date.now()` and `performance.now()`?
`Date.now()` returns epoch milliseconds (wall clock time), while `performance.now()` returns high-resolution floating-point timestamps relative to document navigation start.

#### Q79: What is WebAssembly (WASM)?
A low-level binary instruction format that allows code written in C, C++, or Rust to execute in the browser at near-native speed alongside JavaScript.

#### Q80: How does WebGL accelerate machine learning in the browser?
It represents neural network tensor matrices as 2D texture buffers and utilizes fragment shaders to perform millions of parallel matrix multiplications on the GPU.

#### Q81: What constraints are passed to `getUserMedia`?
`{ video: { width: 640, height: 480, facingMode: "user" } }`.

#### Q82: What is `facingMode: "user"`?
It requests the front-facing selfie camera on mobile phones and tablets.

#### Q83: What is the HTML5 `MediaStreamTrack`?
A single media track (audio or video) inside a `MediaStream`. Calling `track.stop()` halts hardware capture.

#### Q84: What is an HTTP 206 Partial Content status code?
It indicates that the server is serving a chunked byte range of a media file, allowing the browser to stream and seek video without downloading the entire file.

#### Q85: What is CORS, and why is it important for custom video URLs?
Cross-Origin Resource Sharing. If a video server does not send `Access-Control-Allow-Origin: *`, the browser blocks canvas access to its frames, though standard `<video>` playback may still function.

#### Q86: What is a closure in JavaScript?
A function that retains access to its lexical scope even when executed outside that scope. `predictLoop` forms a closure over `animId` and `hiddenCamRef`.

#### Q87: What is the difference between CommonJS and ES Modules?
CommonJS uses synchronous `require()` and `module.exports`, while ES Modules use asynchronous static `import` and `export` statements.

#### Q88: Why does `package.json` have `"type": "module"`?
To tell Node and bundlers that all `.js` files in the repository should be treated as native ES Modules.

#### Q89: What happens if `cancelAnimationFrame` is omitted?
The recursion continues running in memory even after the component unmounts, causing memory leaks and throwing errors on unmounted refs.

#### Q90: What is the difference between `video.play()` and `video.pause()`?
`video.play()` returns a Promise that resolves when playback starts, whereas `video.pause()` executes synchronously.

#### Q91: Why does browser autoplay policy block unmuted video?
To prevent annoying, unexpected sound playback when users load web pages without explicit prior interaction.

#### Q92: What is the purpose of `Math.min(video.duration, currentTime + 10)`?
It ensures that skipping forward never advances the video past its total duration.

#### Q93: What is the purpose of `Math.max(0, currentTime - 10)`?
It prevents seeking to negative timestamps when rewinding near the beginning of the video.

#### Q94: What is `srcObject` on an HTML video element?
A DOM property that accepts a live `MediaStream` object directly from `getUserMedia`, distinct from the standard `src` URL string.

#### Q95: What is the difference between client-side rendering (CSR) and server-side rendering (SSR)?
CSR renders HTML entirely in the browser using JavaScript, whereas SSR generates full HTML on a server before sending it to the client.

#### Q96: Why is SSR incompatible with `getUserMedia`?
Because camera hardware, WebAssembly GPU contexts, and `navigator.mediaDevices` do not exist in Node.js server environments.

#### Q97: What is debouncing?
A technique that postpones function execution until a specific amount of idle time has elapsed since the last trigger.

#### Q98: What is throttling?
A technique that limits function execution to at most once in every specified time window.

#### Q99: Is Touchless Chef using debouncing or throttling?
It uses a **hysteresis cooldown (leading-edge throttle)**: it executes immediately on frame 1, then rejects subsequent triggers for 1500 milliseconds.

#### Q100: What is the role of `navigator.mediaDevices`?
A browser API interface providing access to connected hardware input devices like cameras and microphones.

---

## Group 6: Security, Performance & Interview Deep Dives (Q101 – Q155)

#### Q101: How does Touchless Chef protect user privacy?
By executing all computer vision inference locally in browser memory. Video frames never leave the device.

#### Q102: Could an attacker steal user camera feeds through this app?
No. The application has no backend server or WebSocket connection to transmit video data.

#### Q103: What Content Security Policy directive is required for MediaPipe?
`script-src 'self' 'wasm-unsafe-eval' https://cdn.jsdelivr.net;` to permit WebAssembly memory compilation.

#### Q104: Can an attacker inject malicious JavaScript through the custom URL input?
No. React escapes attribute values, and assigning a `javascript:` URI to `<video src>` causes a media error rather than script execution.

#### Q105: How does the app prevent frame rate drops during video zoom?
By using CSS `transform: scale(...)`, which runs on the GPU compositor thread without triggering layout reflows.

#### Q106: What would happen if `minHandDetectionConfidence` were set to 0.1?
The model would produce numerous false positive hand detections from kitchen towels, pans, and background shadows.

#### Q107: What would happen if `minHandDetectionConfidence` were set to 0.99?
The user would have to hold their hand perfectly flat under bright lighting; slight finger curls would cause detection failures.

#### Q108: Why was a 1500ms cooldown chosen?
User testing showed it matches the natural rhythm of human gestures while preventing accidental double-triggers.

#### Q109: How does the application prevent memory leaks?
By stopping all media tracks on unmount and cancelling the active animation frame ID.

#### Q110: How would you add a volume control gesture?
By tracking vertical movement ($\Delta Y$) of an extended index finger across consecutive frames, mapping distance to `video.volume`.

#### Q111: How would you implement custom gesture training for users?
By using MediaPipe's Web Model Maker API to capture 10 calibration frames per user gesture and training a client-side k-NN classifier.

#### Q112: What is the cold-start download size of the application?
Approximately 5.8 MB total (5.6 MB model bundle + 200 KB JS/CSS assets).

#### Q113: How can cold-start loading time be optimized?
By hosting the `.task` file on a global edge CDN with Brotli compression and Service Worker pre-caching.

#### Q114: What happens if camera permission is denied?
The error is caught in `GestureManager.js`, returning `false`, and the UI displays an amber status banner while manual controls remain active.

#### Q115: How would you test this application in CI/CD without physical webcams?
By using Playwright with Chromium flags `--use-fake-device-for-media-stream` and `--use-file-for-fake-video-capture=test_gesture.y4m`.

#### Q116: What is the Big O time complexity of `predictLoop`?
$\mathcal{O}(1)$ relative to video length or DOM size. MediaPipe processes a fixed 640x480 resolution frame in constant time.

#### Q117: What is the space complexity of the vision engine?
$\mathcal{O}(1)$ constant memory: tensor buffers are pre-allocated in WebAssembly linear memory and reused for every frame.

#### Q118: Why did you use Vite over Create React App?
CRA is deprecated, uses slow Webpack 4/5 builds, and lacks native ES module development serving.

#### Q119: What is Tree-Shaking, and how does it help here?
Rollup's dead-code elimination removes unused Lucide icons and React utilities, keeping the JavaScript bundle compact.

#### Q120: How does `useGesture.js` differ from `ChefVideoPlayer.jsx`?
`useGesture.js` is a standalone reusable hook abstraction, whereas `ChefVideoPlayer.jsx` bundles the player UI, feedback HUD, and command execution logic together.

#### Q121: How do you handle cross-browser camera permissions?
By using the standardized `navigator.mediaDevices.getUserMedia` promise, supported across all modern browsers.

#### Q122: What happens if a video link is broken or returns 404?
The HTML5 video element triggers its native `onError` event, and the browser displays a standard media playback error indicator.

#### Q123: Why is Tailwind's `aspect-video` utility beneficial?
It enforces a modern 16:9 widescreen aspect ratio across all screen resolutions without manual CSS padding hacks.

#### Q124: What is the role of `autoprefixer` in PostCSS?
It automatically adds vendor prefixes like `-webkit-` and `-moz-` to modern CSS rules, ensuring transform animations work across all browsers.

#### Q125: Could this application be packaged into a desktop app?
Yes, using Electron or Tauri, which package the Vite build into a native window with direct OS camera access.

#### Q126: How does WebAssembly manage memory?
It allocates a single continuous linear memory array (`ArrayBuffer`) that can grow dynamically, managed via compiled C++ pointers.

#### Q127: What is the difference between CPU and GPU delegates in MediaPipe?
CPU delegates execute tensor operations using SIMD instructions on processor cores. GPU delegates translate operations into WebGL/WebGPU shaders, achieving 3x to 5x higher throughput.

#### Q128: How does the application handle window resizing?
Tailwind's flexbox and responsive grid layout automatically recalculate layout dimensions without requiring JavaScript resize listeners.

#### Q129: What is the purpose of `playsInline` on the hidden camera element?
It prevents mobile Safari from launching the iOS native fullscreen media player when streaming from the webcam.

#### Q130: Why is `Date.now()` used instead of an incrementing integer counter?
Because animation frame intervals vary depending on device refresh rates (60Hz vs 120Hz vs 144Hz). Wall-clock time guarantees consistent 1.5-second cooldowns regardless of monitor refresh rate.

#### Q131: What happens if the user covers the webcam lens?
MediaPipe detects zero hands (`results.gestures.length === 0`), and `setActiveGesture(null)` clears the HUD tag.

#### Q132: What is an adversarial attack in computer vision?
An intentional visual pattern designed to mislead neural networks. In this project, false positive risks are mitigated by our 0.75 confidence threshold.

#### Q133: Why did you choose 10 seconds for seeking jumps?
Culinary instructions are typically delivered in short, 5 to 15-second instructional segments. Ten seconds allows quick replays without excessive scrubbing.

#### Q134: How would you add multi-language support (i18n)?
By extracting all UI strings into JSON dictionaries (`en.json`, `es.json`, `fr.json`) managed via `i18next`.

#### Q135: What would happen if `useRef` was replaced with a global variable outside the component?
The cooldown would be shared across all instances of `ChefVideoPlayer`, causing state conflicts if multiple players were mounted on the page.

#### Q136: What is the purpose of `postcss.config.js`?
It registers Tailwind CSS and Autoprefixer as transformation plugins for the PostCSS build pipeline.

#### Q137: How does `install.bat` work?
It runs `npm install --legacy-peer-deps` in the current folder, ensuring peer dependency conflicts between Vite plugins do not halt installation.

#### Q138: How does `start.bat` work?
It runs `npm run dev`, triggering the Vite development server on port 5173.

#### Q139: Why is `.gitignore` important in this project?
It prevents committing large `node_modules/` folders, build artifacts (`dist/`), and OS junk files (`.DS_Store`) into version control.

#### Q140: How does Vite achieve sub-second hot module replacement?
When a file is saved, Vite invalidates only that specific ES module on the server and pushes an ESM update to the browser over WebSocket, replacing the module without a full page reload.

#### Q141: What is Subresource Integrity (SRI)?
A security feature enabling browsers to verify that fetched files (such as CDN scripts) haven't been maliciously altered by checking their cryptographic hash.

#### Q142: Why isn't SRI used on the MediaPipe WASM fetch?
MediaPipe dynamically loads internal chunk files at runtime based on browser features, making static hash binding complex across different CDN releases.

#### Q143: How does the UI indicate that the camera is loading?
The control bar displays an amber indicator dot with the message "Initializing MediaPipe Vision Model...".

#### Q144: How does the UI indicate that the camera is active?
The amber indicator dot turns into a pulsing emerald dot with the label "Touchless Control Active (Camera ON)".

#### Q145: What happens when the chef clicks "Show Camera Inset"?
`showPreview` state toggles to `true`, transitioning the mirrored webcam preview from `opacity-0` to `opacity-100`.

#### Q146: Why is `video.style.transition` set inline during zoom?
To ensure the scaling transformation animates smoothly over 300 milliseconds (`transform 0.3s ease`).

#### Q147: What is the advantage of using Lucide icons as React components?
They inherit CSS colors via `currentColor`, scale crisply without pixelation, and support Tailwind utility classes directly.

#### Q148: How does Touchless Chef handle video pauses triggered natively?
The video element has an `onPause` listener that updates React's `isPlaying` state to `false`, keeping UI indicators synchronized.

#### Q149: How does Touchless Chef handle video plays triggered natively?
The video element has an `onPlay` listener that updates React's `isPlaying` state to `true`.

#### Q150: What is a progressive web app (PWA)?
A web application that uses service workers, manifests, and caching to provide an app-like, installable, and offline-capable experience.

#### Q151: How would you add keyboard accessibility shortcuts?
By attaching a `keydown` listener in `useEffect` that maps the Spacebar to play/pause, ArrowRight to skip +10s, and ArrowLeft to rewind -10s.

#### Q152: Why are video elements set to `controls` by default?
To provide a manual fallback control bar, ensuring users without webcams or with disabled permissions can still use the video player.

#### Q153: What is the significance of the ISC License?
A permissive free software license functionally equivalent to the MIT License, allowing unrestricted commercial and private use.

#### Q154: If an interviewer asks: "Why not use WebSockets for gesture control?", how do you reply?
> "WebSockets are designed for bidirectional network communication between client and server. Because our gesture recognition model runs on-device inside WebAssembly, sending video frames over a WebSocket would introduce 200 milliseconds of network latency, burn server bandwidth, and compromise user privacy for zero technical gain."

#### Q155: If an interviewer asks: "What makes this project interview-worthy?", how do you reply?
> "It bridges three high-value engineering domains: high-performance React component lifecycle design, real-time browser hardware manipulation via WebRTC, and edge machine learning deployment using WebAssembly and WebGL shaders. It tackles real-world distributed systems trade-offs—such as latency, cost, and privacy—by shifting compute to the edge."
