# Step 3: Build Order & Implementation Blueprint

This guide presents the architectural order for rebuilding **Touchless Chef** from a blank directory to a fully functioning edge AI application. Each phase outlines the engineering reasoning, file creation path, key code snippets, and line-by-line explanations.

---

## Reconstruction Dependency Graph

```mermaid
flowchart TD
    Phase1["Phase 1: Project Scaffolding & Tooling<br/>(package.json, vite.config.js, tailwind.config.js)"]
    Phase2["Phase 2: Vision Service Layer<br/>(GestureManager.js & gestureMap.js)"]
    Phase3["Phase 3: Video Player & Gesture Loop<br/>(ChefVideoPlayer.jsx)"]
    Phase4["Phase 4: Dashboard & Recipe Manager<br/>(App.jsx & main.jsx)"]
    Phase5["Phase 5: Automation & Production Build<br/>(install.bat, start.bat, vite build)"]

    Phase1 --> Phase2
    Phase2 --> Phase3
    Phase3 --> Phase4
    Phase4 --> Phase5
```

---

## Phase 1: Project Scaffolding & Tooling Setup

### 1. Reasoning
Before writing UI components or vision algorithms, we must establish a modern ECMAScript module build environment capable of handling JSX, PostCSS compilation, and WebAssembly asset resolving.

### 2. Files Created
- `package.json`
- `vite.config.js`
- `tailwind.config.js`
- `postcss.config.js`
- `index.html`

### 3. Key Snippet: `package.json`
```json
{
  "name": "hand-gesture-cv",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "@mediapipe/tasks-vision": "^0.10.14",
    "lucide-react": "^0.441.0",
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.3.3",
    "autoprefixer": "^10.4.20",
    "postcss": "^8.4.49",
    "tailwindcss": "^3.4.15",
    "vite": "^5.4.11"
  }
}
```

### 4. Line-by-Line Explanation
- `"type": "module"`: Enforces native ES module semantics (`import`/`export`) across all source files.
- `"@mediapipe/tasks-vision": "^0.10.14"`: Installs Google's official computer vision WASM SDK.
- `"lucide-react": "^0.441.0"`: Provides tree-shakeable SVG icons for the player controls.
- `"react": "^18.3.1"`: Supplies the React 18 concurrent rendering engine.
- `"vite": "^5.4.11"`: Provides fast esbuild-powered dev server and Rollup production builds.

---

## Phase 2: Edge AI Vision Service Layer

### 1. Reasoning
The computer vision pipeline must be decoupled from the React rendering tree. Creating a singleton service handles model loading, camera stream negotiation, and track termination without polluting component state.

### 2. Files Created
- `src/services/GestureManager.js`
- `src/utils/gestureMap.js`
- `src/services/GestureService.js`

### 3. Key Snippet: `GestureManager.js`
```javascript
import { GestureRecognizer, FilesetResolver } from "@mediapipe/tasks-vision";

class GestureManager {
  constructor() {
    this.recognizer = null;
    this.stream = null;
  }

  async initialize() {
    const vision = await FilesetResolver.forVisionTasks(
      "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm"
    );
    
    this.recognizer = await GestureRecognizer.createFromOptions(vision, {
      baseOptions: {
        modelAssetPath: "https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/1/gesture_recognizer.task",
        delegate: "GPU"
      },
      runningMode: "VIDEO",
      numHands: 1,
      minHandDetectionConfidence: 0.7,
      minTrackingConfidence: 0.7
    });
  }

  async startCamera(videoElement) {
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 480, facingMode: "user" } 
      });
      videoElement.srcObject = this.stream;
      return true;
    } catch (err) {
      console.error("Chef denied camera access:", err);
      return false;
    }
  }

  stop() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
    }
  }
}

export default new GestureManager();
```

### 4. Line-by-Line Explanation
- Lines 4-7: `constructor` initializes instance properties to `null` to ensure safe teardown.
- Lines 10-12: `FilesetResolver.forVisionTasks` dynamically fetches WASM binaries from JSDelivr CDN.
- Lines 14-23: `createFromOptions` compiles Google's float16 quantized neural network on the client's GPU (`delegate: "GPU"`), operating in `"VIDEO"` mode for continuous 60 FPS frame streams.
- Lines 28-30: `getUserMedia` requests front-facing 640x480 video from the client's webcam.
- Lines 39-43: `stop()` iterates through all media tracks and calls `.stop()`, ensuring the camera hardware LED turns off when the component unmounts.
- Line 46: Exports an instantiated singleton instance.

---

## Phase 3: Core Video Player & Gesture Prediction Loop

### 1. Reasoning
Once the vision service is operational, we construct the video player component. It binds the video element, launches the `requestAnimationFrame` inference loop, applies the 1500ms cooldown engine, and dispatches native media commands.

### 2. Files Created
- `src/components/ChefVideoPlayer.jsx`
- `src/components/Gesture/GestureCore.js`

### 3. Key Snippet: `predictLoop` & `executeCommand`
```javascript
const predictLoop = () => {
  if (GestureManager.recognizer && hiddenCamRef.current?.readyState === 4) {
    const results = GestureManager.recognizer.recognizeVideo(hiddenCamRef.current, Date.now());
    
    if (results.gestures && results.gestures.length > 0) {
      const gesture = results.gestures[0][0].categoryName;
      const score = results.gestures[0][0].score;
      
      if (score > 0.75) {
        setActiveGesture(gesture);
        if (Date.now() - lastActionTime.current > 1500) {
          executeCommand(gesture);
          lastActionTime.current = Date.now();
        }
      }
    } else {
      setActiveGesture(null);
    }
  }
  animId = requestAnimationFrame(predictLoop);
};
```

### 4. Line-by-Line Explanation
- Line 2: Validates that the recognizer is initialized and the hidden webcam has loaded video data (`readyState === 4`).
- Line 3: Calls `recognizeVideo` synchronously with the current frame and epoch timestamp.
- Lines 5-8: Extracts predicted category name and confidence score from the top detection candidate.
- Line 10: Discards any prediction with confidence $\le 0.75$.
- Line 12: Evaluates the hysteresis cooldown: `Date.now() - lastActionTime.current > 1500`.
- Lines 13-14: Dispatches the gesture action to the video DOM element and resets `lastActionTime.current`.
- Line 21: Re-registers `predictLoop` on the browser's next vertical refresh cycle via `requestAnimationFrame`.

---

## Phase 4: UI Dashboard & Recipe Management

### 1. Reasoning
Wraps the player with culinary controls: curated recipe stream selectors, custom direct URL ingestion, visual status indicators, and the responsive gesture cheat sheet.

### 2. Files Created
- `src/App.jsx`
- `src/main.jsx`
- `src/index.css`

### 3. Key Snippet: Recipe Switcher & Custom URL Ingestion
```javascript
const [videoUrl, setVideoUrl] = useState(
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'
);
const [customInput, setCustomInput] = useState('');

const handleCustomSubmit = (e) => {
  e.preventDefault();
  if (customInput.trim()) {
    setVideoUrl(customInput.trim());
    setCustomInput('');
  }
};
```

### 4. Line-by-Line Explanation
- Lines 1-3: Establishes root video URL state initialized with a public cloud-hosted video.
- Lines 4: Stores controlled input state for custom user-pasted streams.
- Lines 6-12: Prevents full page reload, trims whitespace, updates `videoUrl`, and resets the input field.

---

## Phase 5: Verification & Launch Automation

### 1. Reasoning
Provides cross-platform developer convenience scripts and builds the production bundle to ensure zero syntax or bundling errors.

### 2. Files Created
- `install.bat` (`npm install --legacy-peer-deps`)
- `start.bat` (`npm run dev`)

### 3. Verification Commands
```bash
# Verify production compilation
npm run build

# Start local development server on port 5173
npm run dev
```
