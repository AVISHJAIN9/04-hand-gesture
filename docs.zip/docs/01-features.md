# Step 2: Feature Inventory & Specification

This document presents the complete technical specification for all **12 core and system features** implemented in Touchless Chef. Every feature is traced from client DOM events to hardware media streams and WebAssembly inference routines.

---

## Feature Master Index

| ID | Feature Name | Primary Files & Functions | Category | Spoken Script Depth |
| :--- | :--- | :--- | :--- | :--- |
| [**F1**](./features/f1-gesture-recognition-engine.md) | Real-Time Edge AI Hand Gesture Recognition Engine | `GestureManager.js:9`, `ChefVideoPlayer.jsx:23` | Core AI / CV | Core (20 lines) |
| [**F2**](./features/f2-touchless-video-control.md) | Touchless Video Play / Pause Control | `ChefVideoPlayer.jsx:62` | Media Control | Medium (9 lines) |
| [**F3**](./features/f3-precision-video-seeking.md) | Precision Video Seeking (+/- 10 Seconds) | `ChefVideoPlayer.jsx:74, 78` | Media Control | Medium (9 lines) |
| [**F4**](./features/f4-interactive-frame-zoom.md) | Interactive Frame Zoom & Inspection (125% / 100%) | `ChefVideoPlayer.jsx:82, 87` | Media Control | Medium (9 lines) |
| [**F5**](./features/f5-gesture-debounce-engine.md) | 1500ms Action Debounce & Cooldown Engine | `ChefVideoPlayer.jsx:8, 33` | Core Engine | Core (16 lines) |
| [**F6**](./features/f6-visual-feedback-hud.md) | Real-Time HUD Overlay & Live Gesture Indicators | `ChefVideoPlayer.jsx:111, 119` | UI / Feedback | Small (6 lines) |
| [**F7**](./features/f7-webcam-preview-inset.md) | Mirrored Vision Stream Inset Monitor & Toggle | `ChefVideoPlayer.jsx:126, 151` | Video / Stream | Medium (8 lines) |
| [**F8**](./features/f8-recipe-video-switcher.md) | Preset Recipe Stream Switcher | `App.jsx:11, 62` | UI / Workflow | Small (6 lines) |
| [**F9**](./features/f9-custom-video-loader.md) | Custom Direct Video Stream / URL Ingestion | `App.jsx:17, 78` | Data / Ingestion | Small (7 lines) |
| [**F10**](./features/f10-camera-lifecycle-manager.md) | Hardware Camera Acquisition & Lifecycle Teardown | `GestureManager.js:26, 39` | Hardware / Stream | Core (15 lines) |
| [**F11**](./features/f11-gesture-mapping-abstraction.md) | Semantic Gesture Command Mapping Architecture | `gestureMap.js:1`, `GestureService.js:1` | Architecture | Small (6 lines) |
| [**F12**](./features/f12-dark-mode-culinary-ui.md) | Dark-Themed Culinary Kitchen UI & Responsive Layout | `App.jsx:26`, `index.css:1` | UI / Styling | Small (6 lines) |

---

## Architectural Interaction Diagram

```mermaid
flowchart TD
    subgraph UI_Layer["User Interface Layer (App.jsx & ChefVideoPlayer.jsx)"]
        F8["F8: Recipe Video Switcher"] --> MainPlayer["Main Video Canvas"]
        F9["F9: Custom Video Loader"] --> MainPlayer
        F12["F12: Dark Kitchen UI"] --> MainPlayer
        MainPlayer --> F6["F6: Floating HUD Badges"]
        MainPlayer --> F7["F7: Mirrored Webcam Inset"]
    end

    subgraph Hardware_And_Vision["Hardware & Edge Vision Layer"]
        F10["F10: Camera Lifecycle & getUserMedia"] --> HiddenCam["Hidden Webcam Stream (640x480)"]
        HiddenCam --> F1["F1: MediaPipe Gesture Recognizer"]
        F1 --> ConfidenceFilter{"Score > 0.75?"}
        ConfidenceFilter -->|Yes| F5["F5: 1500ms Cooldown Engine"]
        F5 --> F11["F11: Semantic Command Mapping"]
    end

    subgraph Action_Dispatch["Playback Execution Layer"]
        F11 --> F2["F2: Play/Pause (Open_Palm)"]
        F11 --> F3["F3: Skip +/-10s (Pointing/Victory)"]
        F11 --> F4["F4: Zoom 125%/100% (Thumbs Up/Down)"]
        F2 --> MainPlayer
        F3 --> MainPlayer
        F4 --> MainPlayer
    end
```

---

## Summary of Feature Implementations

Detailed breakdown files with function signatures, edge case analysis, security audits, and **interview-ready "Say It Out Loud" spoken scripts** are available in the `/docs/features/` folder:

1. [F1: Real-Time Edge AI Hand Gesture Recognition Engine](./features/f1-gesture-recognition-engine.md)
2. [F2: Touchless Video Play / Pause Control](./features/f2-touchless-video-control.md)
3. [F3: Precision Video Seeking (+/- 10 Seconds)](./features/f3-precision-video-seeking.md)
4. [F4: Interactive Frame Zoom & Inspection (125% / 100%)](./features/f4-interactive-frame-zoom.md)
5. [F5: 1500ms Action Debounce & Cooldown Engine](./features/f5-gesture-debounce-engine.md)
6. [F6: Real-Time HUD Overlay & Live Gesture Indicators](./features/f6-visual-feedback-hud.md)
7. [F7: Mirrored Vision Stream Inset Monitor & Toggle](./features/f7-webcam-preview-inset.md)
8. [F8: Preset Recipe Stream Switcher](./features/f8-recipe-video-switcher.md)
9. [F9: Custom Direct Video Stream / URL Ingestion](./features/f9-custom-video-loader.md)
10. [F10: Hardware Camera Acquisition & Lifecycle Teardown](./features/f10-camera-lifecycle-manager.md)
11. [F11: Semantic Gesture Command Mapping Architecture](./features/f11-gesture-mapping-abstraction.md)
12. [F12: Dark-Themed Culinary Kitchen UI & Responsive Layout](./features/f12-dark-mode-culinary-ui.md)

*To rehearse all spoken explanations in a single study guide, navigate to [Step 2.5: Say It Out Loud Guide](./14-say-it-out-loud.md).*
