# Step 6: Architecture & System Design

## 1. High-Level Architecture Overview

**Touchless Chef** operates on a **Decoupled Edge-Computing Client Architecture**. Unlike conventional web applications that stream video to cloud servers for remote inference, Touchless Chef partitions responsibilities entirely to the client device, supported by global Content Delivery Networks for static asset serving.

```mermaid
flowchart TD
    subgraph ClientDevice["Client Hardware & Browser Environment"]
        Webcam["Camera Hardware (640x480 @ 60 FPS)"]
        StreamAPI["HTML5 MediaDevices (getUserMedia)"]
        HiddenCam["Hidden HTML5 Video Buffer (readyState == 4)"]
        
        subgraph EdgeAIEngine["In-Browser MediaPipe Vision Pipeline"]
            WASM["WebAssembly Runtime Module"]
            GPU["WebGL / WebGPU Shader Core"]
            Model["gesture_recognizer.task (float16)"]
            Predict["recognizeVideo(cam, timestamp)"]
        end
        
        subgraph ReactApp["React 18 Application Layer"]
            Player["ChefVideoPlayer Component"]
            Cooldown["1500ms Cooldown Engine (useRef)"]
            Command["executeCommand() Dispatcher"]
            HUD["Floating HUD Overlay"]
            NativeVideo["HTML5 Video Player Element"]
        end
    end

    subgraph ExternalCloud["Global Content Delivery Networks"]
        JSDelivr["JSDelivr CDN (Tasks Vision WASM)"]
        GCSModel["Google Cloud Storage (Model Task Bundle)"]
        GCSMedia["Google Cloud Storage (Sample MP4 Video CDN)"]
    end

    Webcam --> StreamAPI
    StreamAPI --> HiddenCam
    HiddenCam --> Predict
    
    JSDelivr -.->|Download WASM Runtime| WASM
    GCSModel -.->|Fetch Model Weights| Model
    WASM --- GPU
    GPU --- Model
    
    Predict -->|Candidate Category & Score| Player
    Player --> Cooldown
    Cooldown --> Command
    Command --> NativeVideo
    Command --> HUD
    
    GCSMedia -.->|HTTP Range Stream Chunk| NativeVideo
```

---

## 2. Request & Execution Lifecycles (Top 3 Features)

### Lifecycle 1: System Boot & Vision Model Compilation (F1)
```mermaid
sequenceDiagram
    autonumber
    actor User
    participant App as App.jsx
    participant Player as ChefVideoPlayer.jsx
    participant GM as GestureManager.js
    participant CDN as JSDelivr / GCS
    participant Cam as navigator.mediaDevices

    User->>App: Navigates to Application URL
    App->>Player: Mounts ChefVideoPlayer
    Player->>GM: initialize()
    GM->>CDN: GET vision_wasm_internal.wasm
    GM->>CDN: GET gesture_recognizer.task (float16)
    CDN-->>GM: WASM Bytecode & Model Weights
    GM->>GM: Compile GPU Shaders & Alloc Buffers
    Player->>GM: startCamera(hiddenCamRef)
    GM->>Cam: getUserMedia({ video: 640x480 })
    Cam-->>GM: MediaStream Track
    GM-->>Player: hasAccess = true
    Player->>Player: Begin requestAnimationFrame loop
```

### Lifecycle 2: Touchless Play/Pause Command Execution (F2)
```mermaid
sequenceDiagram
    autonumber
    actor Chef
    participant Camera as Hidden Video Element
    participant Recognizer as MediaPipe Recognizer
    participant Player as ChefVideoPlayer.jsx
    participant Timer as lastActionTime Ref
    participant Video as HTML5 Video Element

    Chef->>Camera: Displays Open Palm
    Recognizer->>Camera: Reads frame buffer
    Recognizer->>Recognizer: Computes 21 3D Landmarks & Classifies
    Recognizer-->>Player: [{ categoryName: "Open_Palm", score: 0.89 }]
    Player->>Player: Check score > 0.75 -> PASS
    Player->>Timer: Check Date.now() - lastActionTime.current > 1500
    Timer-->>Player: Elapsed = 2300ms -> PASS
    Player->>Timer: Update lastActionTime.current = Date.now()
    alt Video is Currently Paused
        Player->>Video: video.play()
        Player->>Player: setFeedback("▶️ Playing")
    else Video is Currently Playing
        Player->>Video: video.pause()
        Player->>Player: setFeedback("⏸️ Paused")
    end
```

### Lifecycle 3: Precision Video Scrubbing (F3)
```mermaid
sequenceDiagram
    autonumber
    actor Chef
    participant Recognizer as MediaPipe Recognizer
    participant Player as ChefVideoPlayer.jsx
    participant Video as HTML5 Video Element

    Chef->>Recognizer: Flashes "Pointing_Up" Gesture
    Recognizer-->>Player: Category: Pointing_Up (Score: 0.92)
    Player->>Player: Cooldown Passed
    Player->>Video: currentTime = Math.min(duration, currentTime + 10)
    Video->>Video: Dispatches seeked event & renders target frame
    Player->>Player: setFeedback("⏩ Jumped Forward (+10s)")
```

---

## 3. Data Flow Architecture

```mermaid
flowchart LR
    A["Photons into Camera Sensor"] -->|Analog Light| B["OS Camera Driver"]
    B -->|Uncompressed YUV/RGB Frames| C["Browser WebRTC MediaStream"]
    C -->|640x480 Texture| D["WebGL GPU Texture Buffer"]
    D -->|Tensor Evaluation| E["21 3D Joint Coordinates"]
    E -->|Classifier MLP| F["Gesture Label & Probability Score"]
    F -->|JavaScript Event Loop| G["Action Hysteresis Engine"]
    G -->|Direct DOM Mutation| H["HTML5 Video Element State"]
```

---

## 4. Database Schema & State Representation

### Current In-Memory State
Because Touchless Chef runs completely serverless on the client, state is ephemeral and lives within React 18 component closures:

| State Key | Location | Type | Default Value | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| `videoUrl` | `App.jsx:6` | `string` | BigBuckBunny MP4 URL | Active video stream source |
| `customInput` | `App.jsx:9` | `string` | `""` | Controlled form input for custom URLs |
| `activeGesture` | `ChefVideoPlayer.jsx:9`| `string \| null`| `null` | Live detected pose for HUD tag |
| `cameraActive` | `ChefVideoPlayer.jsx:10`| `boolean` | `false` | Hardware status indicator flag |
| `showPreview` | `ChefVideoPlayer.jsx:11`| `boolean` | `false` | Toggles Picture-in-Picture webcam inset |
| `isPlaying` | `ChefVideoPlayer.jsx:12`| `boolean` | `false` | Synchronized play/pause indicator |
| `feedback` | `ChefVideoPlayer.jsx:13`| `string` | `"Waiting for gesture..."` | Last action notification text |
| `lastActionTime`| `ChefVideoPlayer.jsx:8` | `useRef(number)`| `0` | Epoch timestamp of last executed command |

### Theoretical Production Database Schema (MongoDB / Mongoose)
If persistence were added to support saved user bookmarks and customized recipe playlists:

```mermaid
erDiagram
    USER ||--o{ RECIPE_BOOKMARK : saves
    USER {
        ObjectId _id PK
        string email UK
        string passwordHash
        string fullName
        date createdAt
    }
    RECIPE_BOOKMARK ||--o{ TIMESTAMP_NOTE : contains
    RECIPE_BOOKMARK {
        ObjectId _id PK
        ObjectId userId FK
        string title
        string videoUrl
        int lastPlaybackPosition
        date createdAt
    }
    TIMESTAMP_NOTE {
        ObjectId _id PK
        ObjectId bookmarkId FK
        int timestampSeconds
        string noteText
        string keyTechnique
    }
```

---

## 5. Caching Strategy Across Layers

```mermaid
flowchart TD
    subgraph BrowserCache["Browser Local Caching Layer"]
        ModelCache["HTTP Cache: gesture_recognizer.task (max-age=31536000)"]
        WASMCache["HTTP Cache: vision_wasm_internal.wasm"]
        VideoBuffer["Media Source Buffer (HTTP Range 206 Chunks)"]
    end

    subgraph EdgeCDNCache["Cloudflare / Fastly CDN Layer"]
        StaticBundle["Vite Production Bundle (JS/CSS with Content Hashing)"]
        ModelAssetCDN["Google Cloud Storage Regional Edge Mirrors"]
    end

    StaticBundle --> BrowserCache
    ModelAssetCDN --> ModelCache
```

1. **Model Weight Caching**: The 5.6MB `.task` bundle and WASM runtime include long-lived HTTP caching headers (`Cache-Control: public, max-age=31536000`). Once downloaded on the first visit, subsequent visits load the model directly from the browser's disk cache in under 50ms.
2. **Video Chunk Caching**: Video streams utilize standard HTTP `206 Partial Content` requests. The browser automatically buffers 15–30 seconds ahead of the playback cursor.

---

## 6. Error Handling Strategy Across Layers

| Architectural Layer | Potential Failure | Error Handling Mechanism in Code |
| :--- | :--- | :--- |
| **Hardware / OS** | Webcam not connected or busy | Caught in `GestureManager.js:33-36`; returns `false`, preventing crash. |
| **Browser Security** | User denies camera access | Handled gracefully; UI displays amber banner; manual mouse controls remain functional. |
| **Network / CDN** | Offline or model CDN down | Caught in `setup()` try/catch block ([ChefVideoPlayer.jsx:46-48](file:///c:/Users/lokesh%20lohiya/OneDrive/Desktop/Arnav%20code/new%20project/HandGestureCV-Clean-Project/src/components/ChefVideoPlayer.jsx#L46-L48)). |
| **Computer Vision** | Incomplete hand or poor lighting | Discarded by confidence filter (`score > 0.75`); no erroneous command dispatches. |
| **Media Playback** | Corrupted or 404 video stream | Native HTML5 video error events fire; browser surfaces standard broken media glyph. |

---

## 7. Scaling to 100x Traffic & Bottleneck Analysis

Because **inference is 100% decentralized** (executing on the user's CPU/GPU via WebAssembly), increasing user traffic from 1,000 to 100,000 simultaneous users places **zero compute load on our infrastructure**. 

### The First Three Real Bottlenecks at 100x Scale:
1. **CDN Bandwidth Egress on Video Streams**: Streaming high-definition MP4 videos directly from a single storage bucket to 100,000 concurrent chefs would incur enormous cloud egress charges and saturate bucket rate limits.
   - *Fix*: Migrate video assets to an optimized multi-tier CDN (Cloudflare Stream, Fastly, or AWS CloudFront) using HTTP Live Streaming (HLS / m3u8) with adaptive bitrate chunks.
2. **CDN Cold-Start Rate Limiting for WASM & Model Assets**: If 100,000 users load the 5.6MB model simultaneously during a product launch, public CDNs (JSDelivr/Google Storage) might throttle requests.
   - *Fix*: Self-host model weights on a dedicated global CDN with aggressive brotli compression and edge pre-warming.
3. **Low-End Client Device CPU Throttling**: On inexpensive mobile tablets, continuous 60 FPS WebGL inference causes battery drain and thermal throttling, reducing frame rates from 60 FPS to 15 FPS.
   - *Fix*: Implement adaptive frame skipping (inference every 2nd or 3rd frame, dropping compute frequency to 20–30 FPS while preserving responsive gesture detection).
