import { defineConfig } from 'vitepress';
import { withMermaid } from 'vitepress-plugin-mermaid';

export default withMermaid(
  defineConfig({
    title: "Touchless Chef Docs",
    description: "Interview-Ready Technical Documentation for Touchless Chef Hand Gesture CV",
    appearance: 'dark',
    base: './',

    themeConfig: {
      siteTitle: "Touchless Chef",
      logo: "/icon.png",

      nav: [
        { text: "Guide", link: "/00a-project-analysis" },
        { text: "Features", link: "/01-features" },
        { text: "Spoken Scripts", link: "/14-say-it-out-loud" },
        { text: "API Reference", link: "/03-api-reference" },
        { text: "Comparisons", link: "/04-tech-comparisons" },
        { text: "System Design", link: "/system-design/README" },
        { text: "Interview Q&A", link: "/09-interview-qa" },
        { text: "275 Checklist", link: "/13-master-checklist" },
      ],

      sidebar: [
        {
          text: "0. Project Overview & Pitch",
          items: [
            { text: "Project Type Pre-Check", link: "/00-project-type" },
            { text: "Full Project Analysis", link: "/00a-project-analysis" },
            { text: "30s & 2m Project Pitch", link: "/00b-project-pitch" },
            { text: "Project Map & Tech Stack", link: "/00-project-map" },
          ]
        },
        {
          text: "1. Features & Spoken Rehearsal",
          items: [
            { text: "Feature Inventory Index", link: "/01-features" },
            { text: "F1: Gesture Recognition Engine", link: "/features/f1-gesture-recognition-engine" },
            { text: "F2: Touchless Play / Pause", link: "/features/f2-touchless-video-control" },
            { text: "F3: Precision Seeking (+/- 10s)", link: "/features/f3-precision-video-seeking" },
            { text: "F4: Technique Zoom (125%/100%)", link: "/features/f4-interactive-frame-zoom" },
            { text: "F5: 1500ms Cooldown Engine", link: "/features/f5-gesture-debounce-engine" },
            { text: "F6: Real-Time HUD Overlay", link: "/features/f6-visual-feedback-hud" },
            { text: "F7: Mirrored Webcam Inset", link: "/features/f7-webcam-preview-inset" },
            { text: "F8: Recipe Video Switcher", link: "/features/f8-recipe-video-switcher" },
            { text: "F9: Custom URL Stream Loader", link: "/features/f9-custom-video-loader" },
            { text: "F10: Camera Lifecycle Manager", link: "/features/f10-camera-lifecycle-manager" },
            { text: "F11: Semantic Gesture Mappings", link: "/features/f11-gesture-mapping-abstraction" },
            { text: "F12: Dark Kitchen Culinary UI", link: "/features/f12-dark-mode-culinary-ui" },
            { text: "Say It Out Loud Master Guide", link: "/14-say-it-out-loud" },
          ]
        },
        {
          text: "2. Engineering Blueprints",
          items: [
            { text: "Build Order from Scratch", link: "/02-build-order" },
            { text: "API & Service Reference", link: "/03-api-reference" },
            { text: "Technology Comparisons", link: "/04-tech-comparisons" },
            { text: "Architecture & Data Flow", link: "/05-architecture" },
            { text: "Security Audit (OWASP Top 10)", link: "/06-security" },
            { text: "Edge AI & Vision Deep Dive", link: "/07-ai-integration" },
            { text: "DevOps & Engineering Quality", link: "/08-quality-and-ops" },
          ]
        },
        {
          text: "3. System Design Deep Dive",
          items: [
            { text: "System Design Index", link: "/system-design/README" },
            { text: "14.1 Requirements & Estimation", link: "/system-design/14.1-requirements-and-estimation" },
            { text: "14.2 Architecture Styles", link: "/system-design/14.2-architecture-styles" },
            { text: "14.3 Networking & Protocols", link: "/system-design/14.3-networking-and-communication" },
            { text: "14.4 Load Balancing & Scaling", link: "/system-design/14.4-load-balancing-and-scaling" },
            { text: "14.5 Databases & Storage", link: "/system-design/14.5-databases-and-storage" },
            { text: "14.6 Caching Across Layers", link: "/system-design/14.6-caching" },
            { text: "14.7 Messaging & Async Queues", link: "/system-design/14.7-messaging-and-async" },
            { text: "14.8 Concurrency & Hysteresis", link: "/system-design/14.8-consistency-and-concurrency" },
            { text: "14.9 Reliability & Resilience", link: "/system-design/14.9-reliability-and-resilience" },
            { text: "14.10 API Design & Rate Limiting", link: "/system-design/14.10-api-design-and-rate-limiting" },
            { text: "14.11 Security Architecture", link: "/system-design/14.11-security-architecture" },
            { text: "14.12 Search & AI Architecture", link: "/system-design/14.12-search-and-ai-architecture" },
            { text: "14.13 Real-Time Media Streams", link: "/system-design/14.13-real-time-systems" },
            { text: "14.14 Observability & Operations", link: "/system-design/14.14-observability-and-operations" },
            { text: "14.15 Performance Engineering", link: "/system-design/14.15-performance-engineering" },
            { text: "14.16 Cost & Trade-offs", link: "/system-design/14.16-cost-and-trade-offs" },
            { text: "14.17 Classic System Design", link: "/system-design/14.17-classic-system-design-applied" },
            { text: "14.18 Design Decisions Log", link: "/system-design/decisions" },
          ]
        },
        {
          text: "4. Interview Mastery & Audits",
          items: [
            { text: "155 Interview Questions & Answers", link: "/09-interview-qa" },
            { text: "Gaps & Improvements", link: "/10-gaps-and-improvements" },
            { text: "Technical Glossary", link: "/11-glossary" },
            { text: "Developer Confirmation List", link: "/12-confirm-list" },
            { text: "275-Item Master Checklist", link: "/13-master-checklist" },
          ]
        }
      ],

      search: {
        provider: 'local'
      },

      outline: [2, 3],

      socialLinks: [
        { icon: 'github', link: 'https://github.com/AVISHJAIN9/04-hand-gesture' }
      ],

      footer: {
        message: 'Released under the ISC License. Built with VitePress & Google MediaPipe.',
        copyright: 'Copyright © 2026 Touchless Chef Authors'
      }
    },

    mermaid: {
      theme: 'dark'
    }
  })
);
