# Step 12: Developer Confirmation Checklist (`[CONFIRM WITH DEVELOPER]`)

In compliance with **Rule 3** of the documentation standard, whenever the underlying motivation behind an architectural, tooling, or engineering design decision could not be definitively extracted from raw source code alone, a plausible rationale was formulated and marked with **`[CONFIRM WITH DEVELOPER]`**.

This checklist gathers all flagged items into a single verification manifest so the primary developer can review and confirm them before technical interviews.

---

## Developer Verification Items

| Reference Section | Topic & Flagged Assumption | Stated Rationale in Documentation | Developer Status |
| :--- | :--- | :--- | :--- |
| **Tech Comparisons §1** | Choice of **Google MediaPipe Vision Tasks** over TensorFlow.js | Chosen because MediaPipe provides pre-trained 21-point 3D hand landmark recognition and gesture classification out of the box with WebGL GPU delegates, avoiding the need to collect custom training datasets or train secondary classifiers. `[CONFIRM WITH DEVELOPER]` | [ ] Confirmed<br/>[ ] Modify |
| **Tech Comparisons §2** | Choice of **React 18** over Vue 3 or Vanilla JS | Chosen because `useRef` provides an isolated, mutable container for tracking 60 FPS animation loops and cooldown timestamps without triggering component re-renders, coupled with React's industry-standard hiring familiarity. `[CONFIRM WITH DEVELOPER]` | [ ] Confirmed<br/>[ ] Modify |
| **Tech Comparisons §3** | Choice of **Vite 5** over Webpack 5 or Next.js | Chosen for native ES module dev server startup, sub-second Hot Module Replacement, and out-of-the-box WebAssembly asset resolving, avoiding SSR complexity since `getUserMedia` is strictly a client API. `[CONFIRM WITH DEVELOPER]` | [ ] Confirmed<br/>[ ] Modify |
| **Tech Comparisons §4** | Choice of **Tailwind CSS v3** over Styled Components | Chosen because build-time utility CSS compiles to under 10KB of pure CSS with zero JavaScript runtime overhead, ensuring style calculations never drop frames during high-frequency computer vision loops. `[CONFIRM WITH DEVELOPER]` | [ ] Confirmed<br/>[ ] Modify |
| **Tech Comparisons §5** | Choice of **`useRef` Timestamp Hysteresis** over Lodash `debounce` | Chosen because video player control requires immediate leading-edge actuation rather than trailing-edge delays, while silently suppressing subsequent triggers for 1500ms without triggering React re-renders. `[CONFIRM WITH DEVELOPER]` | [ ] Confirmed<br/>[ ] Modify |
| **Feature F3 Trace** | Selection of **10-Second Seeking Interval** | Chosen because culinary instructions are typically delivered in short, 5 to 15-second instructional segments, making 10 seconds the optimal increment for replaying missed steps. `[CONFIRM WITH DEVELOPER]` | [ ] Confirmed<br/>[ ] Modify |
| **Feature F4 Trace** | Selection of **125% Zoom Scale Factor** | Chosen because 125% magnification provides close-up visual inspection of delicate knife angles while remaining fully contained within the player's `overflow-hidden` container without clipping critical culinary action. `[CONFIRM WITH DEVELOPER]` | [ ] Confirmed<br/>[ ] Modify |
| **Architecture §7** | Scalability Decision on **Zero Backend** | Chosen to maintain absolute zero hosting cost and 100% user privacy, as culinary video control does not strictly require persistent user accounts or server-side telemetry in its initial release. `[CONFIRM WITH DEVELOPER]` | [ ] Confirmed<br/>[ ] Modify |

---

## Action for the Developer
1. Review each stated rationale above.
2. Confirm if the assumption matches your original thinking during development.
3. If your personal motivation differed (e.g., *"I used Vite because I previously had great experience with it on another project"* or *"I chose 10 seconds because YouTube uses 10-second jumps"*), update the respective file.
